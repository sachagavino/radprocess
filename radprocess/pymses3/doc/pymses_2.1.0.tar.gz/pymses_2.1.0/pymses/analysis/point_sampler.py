# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
import numpy

def sample_points(amr_source, points, add_level=False):#{{{
	r"""
	Create point-based data from AMR-based data by point sampling. Samples all available fields
	of the `amr_source` at the coordinates of the `points`.
	
	Parameters
	----------
	amr_source : :class:`~pymses.sources.ramses.output.RamsesAmrSource`
		data description
	points : (`npoints`, `ndim`) ``array``
		sampling points coordinates
	add_level : ``boolean`` (default False)
		whether we need the AMR level information
	
	Returns
	-------
	dset : :class:`~pymses.core.datasets.PointDataset`
		Contains all these sampled values.
	
	"""
	points = numpy.asarray(points)
	npoints = points.shape[0]

	# Compute the domain ids of the points
	points_datamap = amr_source.dom_decomp.map_points(points)
	# Sort the points by datamap
	unique_domains = numpy.unique(points_datamap)
	
	ipoint_batches = []
	point_dsets = []

	# Loop over unique domains
	for idomain in unique_domains:
		# Select points from current domain only
		ipoint_batch = numpy.nonzero(points_datamap == idomain)[0]
		ipoint_batches.append(ipoint_batch)
		points_in_domain = points[ipoint_batch, :]
		
		# Read the cell dataset of the current domain
		dset = amr_source.get_domain_dset(idomain)

		# Sample on the current domain
		point_dsets.append(dset.sample_points(points_in_domain, add_level))

	# Perform final reordering concatenation
	cat_method = point_dsets[0].concatenate
	return cat_method(point_dsets, reorder_indices=ipoint_batches)
#}}}

__all__ = ["sample_points"]
