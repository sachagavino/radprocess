# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
from tempfile import mkstemp
from os import listdir
from os.path import basename, dirname
from pymses.utils import constants as C
from pymses.sources.ramses.output import RamsesOutput
from pymses.sources.ramses.filename_utils import search_valid_outputs
from pymses.utils.regions import Box
from pymses.analysis.visualization import *
from pymses.filters.cell_to_points import *
from pymses.filters.region_filter import *
from utils import get_appropriate_unit
import numpy as N
import tables as T

class RamsesModel:#{{{
	
	tunit_dict = {'yr': C.year, 'Myr': C.Myr, 'Gyr': C.Gyr}

	def __init__(self):
		self.ramses_dir = None
		self.iout_list = None
		self.ro = None
	

	def SearchValidOutputs(self, out_dir):#{{{
		"""
		Search for valid RAMSES outputs in the out_dir directory
		Records the ramses_dir and the sorted iout_list if valid outputs are found and return True
		Return False if none is found
		"""
		if out_dir is None:
			if self.ramses_dir is None:
				return False
			else:
				out_dir = self.ramses_dir
		ilist = search_valid_outputs(out_dir)
		ok = (len(ilist) > 0)
		if ok:
			self.iout_list = ilist
			self.ramses_dir = out_dir
		return ok
	#}}}

	def GetvalidOutputsList(self):
		return self.iout_list

	def SetRamsesOutput(self, iout_index, init_ramses_sim):#{{{
		"""
		If iout is in self.iout_list :
		- Sets the chosen RamsesOutput according to the iout number
		- Init. the region size (boxlen)
		- Return True

		Return False if not.
		"""
		if not iout_index in range(len(self.iout_list)):
			return False
		iout = self.iout_list[iout_index]
		self.ro = RamsesOutput(self.ramses_dir, iout)
		if init_ramses_sim:
			self.SetRegionSizeUnit(self.ro.info["unit_length"])
		return True
	#}}}

	def GetOutputTime(self):#{{{
		t = self.ro.info["unit_time"] * self.ro.info["time"]
		return get_appropriate_unit(t, RamsesModel.tunit_dict)
	#}}}

#}}}


class MapEngine(object):#{{{
	def __init__(self, field_list, ramses_output):
		self.field_list = field_list
		self.ramses_output = ramses_output
		self.source = self.ramses_output.amr_source(self.field_list)

	def MakeMaps(self, los_cam, cam_dict):#{{{
		# Map computation
		self.map_h5files={}
		mp = fft_projection.MapFFTProcessor(self.source, self.ramses_output.info, pre_flatten=True)
		for axis, cam in cam_dict.iteritems():
				# Map parameters
				mapname = "wx_AMRViewer_%s_%s_"%(self.getMapName(),axis)
				fhandle, fname = mkstemp(prefix=mapname, suffix=".h5")
				mname = basename(fname)[:-3]
				tdir = dirname(fname)

				scal_func = self.getMapOperator(cam)
				mmap = mp.process(scal_func, cam, surf_qty=self.IsSurfQuantity())
				mu = self.getMapUnit()
				au = self.ramses_output.info["unit_length"]
				self.map_h5files[axis] = save_map_HDF5(mmap, cam, unit=mu, scale_unit=au, hdf5_path=tdir, map_name=mname)

		keys = self.map_h5files.keys()
		def h5f_iter():
				for k in keys:
						yield self.map_h5files[k]

		img_iter = save_HDF5_seq_to_img(h5f_iter, cmap=self.get_cmap(), fraction=0.1)
		imglist = [img for img in img_iter()]
		img_dict = dict(zip(keys, imglist))
		return img_dict
	#}}}
		
	def get_cmap(self):
		return "jet"

	def GetAppropriateUnit(self, value):#{{{
		v = value * self.getMapUnit()
		return get_appropriate_unit(v, self.getUnitDict())
	#}}}

	def GetMapArrays(self):#{{{
		"""
		Get the numpy.array of the maps contained in each HDF5 file of
		the self.h5files dict.
		The returned maps are maskred and clipped.
		"""
		ma = {}
		for axis, h5fname in self.map_h5files.iteritems():
			h5f = T.openFile(h5fname, 'r')
			cam = Camera.from_HDF5(h5f)
			map = h5f.getNode("/map/map").read()
			map_mask = h5f.getNode("/map/map_mask").read()
			h5f.close()
			nx, ny = map.shape
#			map = map.transpose()
#			map_mask = map_mask.transpose()
			vmin, vmax = get_map_range(map[(map_mask>0.)], cam.log_sensitive, None, 0.1)
			map = N.clip(map[:,::-1], vmin, vmax)
			if cam.log_sensitive:
				map = 10.**map
			ma[axis] = map
		return ma
	#}}}

	def getMapName(self):
		raise NotImplementedError()
	
	def getUnitDict(self):
		raise NotImplementedError()

	def getMapUnit(self):
		raise NotImplementedError()

	def getMapOperator(self, cam):
		raise NotImplementedError()

	def IsSurfQuantity(self):
		return False

	
#}}}

class RayTraceEngine(MapEngine):#{{{
	def __init__(self, ramses_output):
		fl = ["rho"]
		MapEngine.__init__(self, fl, ramses_output)
		self.rt = raytracing.RayTracer(ramses_output, fl)
	
	def MakeMaps(self, los_cam, cam_dict):#{{{
		# Map computation
		self.map_h5files={}
		for axis, cam in cam_dict.iteritems():
			cam.log_sensitive = False
			# Map parameters
			mapname = "wx_AMRViewer_%s_%s_"%(self.getMapName(),axis)
			fhandle, fname = mkstemp(prefix=mapname, suffix=".h5")
			mname = basename(fname)[:-3]
			tdir = dirname(fname)

			scal_func = self.getMapOperator(cam)
			mmap = self.rt.process(scal_func, cam, surf_qty=self.IsSurfQuantity())
			mu = self.getMapUnit()
			au = self.ramses_output.info["unit_length"]
			self.map_h5files[axis] = save_map_HDF5(mmap, cam, unit=mu, scale_unit=au, hdf5_path=tdir, map_name=mname)

		keys = self.map_h5files.keys()
		def h5f_iter():
			for k in keys:
				yield self.map_h5files[k]

		img_iter = save_HDF5_seq_to_img(h5f_iter, cmap="jet", fraction=0.1, discrete=True)
		imglist = [img for img in img_iter()]
		img_dict = dict(zip(keys, imglist))
		return img_dict
	#}}}

	def GetAppropriateUnit(self, value):#{{{
		v = value * self.getMapUnit()
		return get_appropriate_unit(v, self.getUnitDict())
	#}}}

	def GetMapArrays(self):#{{{
		"""
		Get the numpy.array of the maps contained in each HDF5 file of
		the self.h5files dict.
		The returned maps are maskred and clipped.
		"""
		ma = {}
		for axis, h5fname in self.map_h5files.iteritems():
			h5f = T.openFile(h5fname, 'r')
			cam = Camera.from_HDF5(h5f)
			map = h5f.getNode("/map/map").read()
			map_mask = h5f.getNode("/map/map_mask").read()
			h5f.close()
			nx, ny = map.shape
			vmin, vmax = get_map_range(map[(map_mask>0.)], cam.log_sensitive, None, 0.1)
			map = N.clip(map[:,::-1], vmin, vmax)
			if cam.log_sensitive:
				map = 10.**map
			ma[axis] = map
		return ma
	#}}}

	@classmethod
	def is_map_engine_for(cls, map_type):
		return map_type == "levelmax"
	
	def getMapName(self):
		return "amr_max_ref_level"

	def getMapUnit(self):
		return C.none

	def getUnitDict(self):
		d = {"": C.none}
		return d
			
	def getMapOperator(self, cam):
		op = MaxLevelOperator()
		return op
#}}}

class MassWeightedDensityMapEngine(MapEngine):#{{{
	def __init__(self, ramses_output):
		MapEngine.__init__(self, ["rho"], ramses_output)

	@classmethod
	def is_map_engine_for(cls, map_type):
		return map_type == "rho"

	def getMapName(self):
		return "gas_mw_density"

	def getMapUnit(self):
		return self.ramses_output.info["unit_density"]

	def getUnitDict(self):
		d = {"H/cc": C.H_cc}
		return d
			
	def getMapOperator(self, cam):
		num_func = lambda dset: (dset["rho"]**2 * dset.get_sizes()**3)
		denom_func = lambda dset: (dset["rho"] * dset.get_sizes()**3)
		return FractionOperator(num_func, denom_func)
#}}}

class SurfaceDensityMapEngine(MapEngine):#{{{
	def __init__(self, ramses_output):
		MapEngine.__init__(self, ["rho"], ramses_output)
	
	@classmethod
	def is_map_engine_for(cls, map_type):
		return map_type == "Sigma"
	
	def getMapName(self):
		return "gas_Sigma"

	def getUnitDict(self):
		d = {"Msun/pc^2": C.Msun/C.pc**2}
		return d
	
	def getMapUnit(self):
		u = self.ramses_output.info["unit_density"] * \
				self.ramses_output.info["unit_length"]
		return u
			
	def getMapOperator(self, cam):
		f = ScalarOperator(lambda dset: (dset["rho"] * dset.get_sizes()**3))
		return f
	
	def IsSurfQuantity(self):
		return True
#}}}

class MassWeightedTemperatureMapEngine(MapEngine):#{{{
	def __init__(self, ramses_output):
		MapEngine.__init__(self, ["P", "rho"], ramses_output)
	
	@classmethod
	def is_map_engine_for(cls, map_type):
		return map_type == "T"
	
	def getMapName(self):
		return "gas_mw_T"
	
	def getUnitDict(self):
		d = {"K": C.K}
		return d

	def getMapUnit(self):
		return self.ramses_output.info["unit_temperature"]
			
	def getMapOperator(self, cam):
		num_func = lambda dset: (dset["P"] * dset.get_sizes()**3)
		denom_func = lambda dset: (dset["rho"] * dset.get_sizes()**3)
		return FractionOperator(num_func, denom_func)
#}}}

# Line-of-sight velocity map engines {{{
class MassWeightedLosVelocityMapEngine(MapEngine):#{{{
	def __init__(self, ramses_output):
		MapEngine.__init__(self, ["vel", "rho"], ramses_output)
	
	@classmethod
	def is_map_engine_for(cls, map_type):
		return map_type == "Vlos"

	def MakeMaps(self, los_cam, cam_dict):
		for c in cam_dict.values():
			c.log_sensitive = False
		return MapEngine.MakeMaps(self, los_cam, cam_dict)

	def getMapName(self):
		return "gas_mw_Vlos"
	
	def getUnitDict(self):
		d = {"km/s": C.km/C.s}
		return d
	
	def getMapUnit(self):
		return self.ramses_output.info["unit_velocity"]

	def getMapOperator(self, cam):
		num_func = lambda dset: (-N.sum(cam.los_axis[N.newaxis,:] * dset["vel"], axis=1) *\
				dset["rho"] * dset.get_sizes()**3)
		denom_func = lambda dset: (dset["rho"] * dset.get_sizes()**3)
		return FractionOperator(num_func, denom_func)

	def get_cmap(self):
		return "RdBu_r"
#}}}

class MassWeightedLosVelocityDispMapEngine(MapEngine):#{{{
	def __init__(self, ramses_output):
		MapEngine.__init__(self, ["vel", "rho"], ramses_output)
	
	@classmethod
	def is_map_engine_for(cls, map_type):
		return map_type == "sigma"
	
	def getMapName(self):
		return "gas_mw_sigma_Vlos"
	
	def getUnitDict(self):
		d = {"km/s": C.km/C.s}
		return d
	
	def getMapUnit(self):
		return self.ramses_output.info["unit_velocity"]

	def getMapOperator(self, cam):
		num_func = lambda dset: (-N.sum(cam.los_axis[N.newaxis,:] * dset["vel"], axis=1) *\
				dset["rho"] * dset.get_sizes()**3)
		denom_func = lambda dset: (dset["rho"] * dset.get_sizes()**3)
		return FractionOperator(num_func, denom_func)
#}}}

#}}}



def map_engine(map_type, ramses_output):#{{{
	for cls in MapEngine.__subclasses__():
		if cls.is_map_engine_for(map_type):
			return cls(ramses_output)
	raise ValueError("No MapEngine available for map type '%s'"%map_type)
#}}}
