# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
import wx
from widget_ids import WidgetIds as wid
from about import open_about_box
from left_panel import LeftPanel
from notebook import Notebook
from dialogs import *
from ..ctrl import Controller
from utils import get_icon

class GUI(wx.App):#{{{
	def OnInit(self):
		frame = MainWindow(None, title='AMRViewer')
		self.SetTopWindow(frame)
		return True

	def run(self):
		self.MainLoop()

#}}}

class MainWindow(wx.Frame):#{{{

	def __init__(self, parent, title):#{{{
		"""
		"""
		WID = wid()
		wx.Frame.__init__(self, parent, WID.ANY, title=title)
				
		# Controller
		self.controller = Controller(self)

		# Model
		self.model = self.controller.model


		# Setting up the menubar {{{
		filemenu= wx.Menu()
		menuOpen = filemenu.Append(WID.MENU_OPEN, "&Open RAMSES simulation"," Open a RAMSES outputs directory")
		menuExit = filemenu.Append(WID.MENU_QUIT,"&Quit"," Terminate the AMRViewer")
		
		cameramenu= wx.Menu()
		menuLoadCam = cameramenu.Append(WID.MENU_LOADCAM, "&Load camera..."," Load a camera from a HDF5 file")
		menuSaveCam = cameramenu.Append(WID.MENU_SAVECAM, "&Save camera into file..."," Save the camera into a HDF5 file")

		tabdisplaymenu= wx.Menu()
		for tab_index in range(len(WID.TAB_NAME_LIST)):
			tab_name = WID.TAB_NAME_LIST[tab_index]
			descr = WID.TAB_DESCR_LIST[tab_name]
			tabdisplaymenu.Append(WID.TAB_MENU_IDS[tab_name], "%s"%descr," Show/hide tab : '%s'"%descr, wx.ITEM_CHECK)
		
		helpmenu= wx.Menu()
		menuAbout= helpmenu.Append(WID.MENU_ABOUT, "&About"," Information on AMRViewer")
		
		menuBar = wx.MenuBar()
		menuBar.Append(filemenu,"&File") # Adding the "filemenu" to the MenuBar
		menuBar.Append(cameramenu,"&Camera") # Adding the "cameramenu" to the MenuBar
		menuBar.Append(tabdisplaymenu,"&Display") # Adding the "tabdisplaymenu" to the MenuBar
		menuBar.Append(helpmenu,"&Help") # Adding the "helpmenu" to the MenuBar
		self.SetMenuBar(menuBar)  # Adding the MenuBar to the Frame content.
		#}}}
		
		# Toolbar creation + events {{{
		sizer = wx.BoxSizer(wx.VERTICAL)
		self.SetSizer(sizer)
		toolbar = wx.ToolBar(self, -1, style=wx.TB_HORIZONTAL | wx.NO_BORDER)
		toolbar.AddSimpleTool(WID.TOOL_OPEN, wx.Bitmap(get_icon("open.png")), '', 'Open a RAMSES outputs directory')
		toolbar.AddSimpleTool(WID.TOOL_RESET, wx.Bitmap(get_icon("reset.png")), '', 'Reset view')
		toolbar.AddSeparator()
		toolbar.AddSimpleTool(WID.TOOL_QUIT, wx.Bitmap(get_icon("quit.png")), '', 'Terminate the AMRViewer')
		toolbar.Realize()
		sizer.Add(toolbar, 0, border=2)
		#}}}
		
		# StatusBar {{{
		self.CreateStatusBar(2) # A Statusbar in the bottom of the window
		self.SetStatusWidths([-5,-2])
		#}}}
		
		# Frame Content {{{
		mainpanel = wx.Panel(self, WID.ANY, style=wx.RAISED_BORDER)
		sizer.Add(mainpanel, 1, wx.EXPAND)
		sizer2 = wx.BoxSizer(wx.HORIZONTAL)
		mainpanel.SetSizer(sizer2)
		self.lp = LeftPanel(mainpanel, self.model, self.controller)
		self.rp = Notebook(mainpanel, self.model, self.controller)
		sizer2.Add(self.lp, 0, wx.ALL|wx.EXPAND|wx.ALIGN_CENTER, 2)
		sizer2.Add(self.rp, 1, wx.ALL|wx.EXPAND|wx.ALIGN_CENTER, 2)
		#}}}
		
		# Widgets {{{
		self.widgets = {
						WID.EXPANDER_RAMSES: self.lp.cpr, \
						WID.EXPANDER_LOS: self.lp.cpa, \
						WID.EXPANDER_GLASS: self.lp.cpg, \
						WID.EXPANDER_RULE: self.lp.cprule, \
						WID.RULE_VALUE: self.lp.cprule.rule_value, \
						WID.RULE_UNIT: self.lp.cprule.rule_unit, \
						WID.RF_TAB: self.rp.rf_tab, \
						}
		for tab_name, tab_id in WID.TAB_IDS.iteritems():
			self.widgets[tab_id] = self.rp.map_tabs[tab_name]
		#}}}
		
		# Controller
		self.controller.SetWidgetsDict(self.widgets)

		# Controller reset
		self.controller.OnReset(None)
		
		# Events binding
		self.bind_events()
		
		self.SetAutoLayout(1)
		self.Fit()
		self.SetMinSize(self.GetSize())
		self.Center()
		self.Show()
	#}}}
		
	def reset(self):#{{{
		self.lp.reset()
		self.rp.reset()
	#}}}

	def bind_events(self):#{{{
		WID = wid()
		self.Bind(wx.EVT_MENU, self.OnOpen,    id=WID.MENU_OPEN)
		self.Bind(wx.EVT_TOOL, self.OnExit,    id=WID.MENU_QUIT)
		
		self.Bind(wx.EVT_MENU, self.OnLoadCam, id=WID.MENU_LOADCAM)
		self.Bind(wx.EVT_MENU, self.OnSaveCam, id=WID.MENU_SAVECAM)
		
		for tid in WID.TAB_MENU_IDS.values():
			self.Bind(wx.EVT_MENU, self.OnDisplayHideTab, id=tid)
		
		self.Bind(wx.EVT_MENU, self.OnAbout,   id=WID.MENU_ABOUT)
		
		self.Bind(wx.EVT_TOOL, self.OnOpen,    id=WID.TOOL_OPEN)
		self.Bind(wx.EVT_MENU, self.OnExit,    id=WID.TOOL_QUIT)
		self.Bind(wx.EVT_TOOL, self.controller.OnReset, id=WID.TOOL_RESET)
	
		self.Bind(wx.EVT_COLLAPSIBLEPANE_CHANGED, self.UpdateLayout)
	#}}}

	def UpdateLayout(self, event):
		self.Layout()

	def OnAbout(self,event):
		open_about_box(self)
	
	def OnExit(self,event):#{{{
		dial = wx.MessageDialog(self, 'Are you sure you want to quit ?', 'Exit', \
				wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION)
		if dial.ShowModal() == wx.ID_YES:
			self.Close(True)
	#}}}
	
	def OnOpen(self,event):#{{{
		"""
		Open a RamsesSimOuputDialog
		"""
		WID = wid()
		win = RamsesSimOutputDialog(self, self.widgets[WID.EXPANDER_RAMSES])
		win.run()
	#}}}
	
	def OnLoadCam(self,event):#{{{
		"""
		Open a CameraHDF5FileDialog and let the user choose a HDF5 file
		from which a Camera is loaded
		"""
		WID = wid()
		win = CameraHDF5FileDialog(self, self.controller, True)
		win.run()
	#}}}
	
	def OnSaveCam(self,event):#{{{
		"""
		Open a CameraHDF5FileDialog and let the user choose a HDF5 file
		in which a Camera is saved
		"""
		WID = wid()
		win = CameraHDF5FileDialog(self, self.controller, False)
		win.run()
	#}}}

	def OnDisplayHideTab(self, event):#{{{
		WID = wid()
		tid = event.GetId()
		for tab_name, tab_menu_id in WID.TAB_MENU_IDS.iteritems():
			if (tab_menu_id == tid):
				tab = self.widgets[WID.TAB_IDS[tab_name]]
				if tab.IsShown():
					tab.Hide()
				else:
					tab.Show()
				break
	#}}}

#}}}

def run():
	gui = GUI()
	gui.run()
