# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
import wx

class WidgetIds(object):
	class __wid:
		def __init__(self):#{{{
			self.ANY = wx.ID_ANY
			
			# Tools
			self.TOOL_OPEN    = wx.NewId()
			self.TOOL_RESET   = wx.NewId()
			self.TOOL_QUIT    = wx.NewId()
			
			# Menu
			self.MENU_OPEN    = wx.ID_OPEN
			self.MENU_SAVECAM = wx.NewId()
			self.MENU_LOADCAM = wx.NewId()
			self.MENU_QUIT    = wx.ID_EXIT
			self.MENU_ABOUT   = wx.ID_ABOUT

			# Expanders
			self.EXPANDER_RAMSES = wx.NewId()
			self.EXPANDER_LOS    = wx.NewId()
			self.EXPANDER_GLASS  = wx.NewId()
			self.EXPANDER_RULE   = wx.NewId()

			# Line-of-sight widgets
			self.LOS_A3D             = wx.NewId()
			self.LOS_TOOL_X          = wx.NewId()
			self.LOS_TOOL_MX         = wx.NewId()
			self.LOS_TOOL_Y          = wx.NewId()
			self.LOS_TOOL_MY         = wx.NewId()
			self.LOS_TOOL_Z          = wx.NewId()
			self.LOS_TOOL_MZ         = wx.NewId()
			self.LOS_TOOL_ROT_LEFT   = wx.NewId()
			self.LOS_TOOL_ROT_RIGHT  = wx.NewId()
			self.LOS_TOOL_ROT_TOP    = wx.NewId()
			self.LOS_TOOL_ROT_BOTTOM = wx.NewId()

			# Magnifying glass widgets
			self.GLASS_WIN = wx.NewId()
			self.GLASS_VAL = wx.NewId()
			
			# Magnifying glass widgets
			self.RULE_VALUE = wx.NewId()
			self.RULE_UNIT  = wx.NewId()
			
			# Region finder tab
			self.RF_TAB            = wx.NewId()
			self.RF_TAB_LOS_WIN    = wx.NewId()
			self.RF_TAB_U_WIN      = wx.NewId()
			self.RF_TAB_V_WIN      = wx.NewId()

			# Other tabs
			# Before any addition to these 2 lists, let's say "item", make sure :
			# - you added a 60x20 pixels image in the view/icons directory named 'item.png'
			self.TAB_NAME_LIST = ["levelmax", "rho", "Sigma", "T", "Vlos"]#, "sigma"]
			self.TAB_DESCR_LIST = {"levelmax": "Max. AMR level of refinement along the line-of-sight",\
								   "rho": "Mass-weighted gas density",\
								   "Sigma": "Gas surface density",\
								   "T": "Mass-weighted gas temperature",\
								   "Vlos": "Mass-weighted line-of-sight gas velocity"}#,\
#								   "sigma": "Mass-weighted line-of-sight gas velocity dispersion"}
			####### DO NOT MODIFY BELOW THIS LINE ##########
			self.TAB_WIN_IDS = {}                          #
			self.TAB_IDS = {}                              #
			self.TAB_MENU_IDS = {}                         #
			for tab_name in self.TAB_NAME_LIST:            #
				self.TAB_WIN_IDS[tab_name] = wx.NewId()    #
				self.TAB_IDS[tab_name] = wx.NewId()        #
				self.TAB_MENU_IDS[tab_name] = wx.NewId()   #
			################################################
			
		#}}}

	instance = None
	
	def __new__(c): # _new_ is always a class method
		if not WidgetIds.instance:
			WidgetIds.instance = WidgetIds.__wid()
		return WidgetIds.instance
	
	def __getattr__(self, attr):
		return getattr(self.instance, attr)

	def __setattr__(self, attr, val):
		pass
