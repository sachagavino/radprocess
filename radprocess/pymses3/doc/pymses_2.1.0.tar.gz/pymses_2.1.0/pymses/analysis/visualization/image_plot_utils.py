# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
import tables
import numpy
import pylab
import Image
import os
from matplotlib.colors import Colormap, LinearSegmentedColormap
from pymses.utils.constants import Unit
from camera import Camera



def save_map_HDF5(map, camera, unit=None, scale_unit=None, hdf5_path="./", map_name="my_map"):#{{{
	r"""
	Saves the map and the camera into a HDF5 file

	"""
	map_mask = camera.get_map_mask()
	nx, ny = camera.get_map_size()
	map_size = numpy.array([nx, ny])
	map_range = numpy.array([numpy.min(map), numpy.max(map)])
	fname = os.path.join(hdf5_path, "%s.h5"%map_name)
	print "Saving map into '%s' HDF5 file"%fname
	h5f = tables.openFile(fname, mode='w')
	h5f.createArray("/", "name", map_name)
	camera.save_HDF5(h5f)
	h5f.createGroup("/", "map")
	h5f.createArray("/map", "map", map)
	h5f.createArray("/map", "map_mask", map_mask)
	h5f.createArray("/map", "map_size", map_size)
	h5f.createArray("/map", "map_range", map_range)
	if unit is not None:
		h5f.createGroup("/map", "unit")
		h5f.createArray("/map/unit", "dimensions", unit.dimensions)
		h5f.createArray("/map/unit", "val", unit.val)
	if scale_unit is not None:
		h5f.createGroup("/map", "length_unit")
		h5f.createArray("/map/length_unit", "dimensions", scale_unit.dimensions)
		h5f.createArray("/map/length_unit", "val", scale_unit.val)
	
	h5f.close()
	return fname
#}}}

def save_HDF5_to_img(h5fname, img_path=None, cmap="jet", cmap_range=None, fraction=None, discrete=False):#{{{
	"""
	Function that plots, from an HDF5 file, the map into a Image and saves it into a PNG file

	Parameters
	----------
	h5fname      : ``string``
		the name of the HDF5 file containing the map
	img_path     : ``string``
		the path in wich the img file is to be saved. the image is returned (and not saved) if left to None (default value)
	cmap         : ``string`` or ``Colormap`` object
		colormap to use
	cmap_range   : [`vmin`, `vmax`] ``array``
		value range for map values clipping (linear scale)
	fraction     : ``float``
		fraction of the total map values below the min. map range (in percent)
	discrete     : ``boolean``
		whether the colormap must be integer values only or not.

	Returns
	-------
	img : PIL ``Image``
		if `img_path` is left to None

	"""
	h5f = tables.openFile(h5fname, 'r')
	cam = Camera.from_HDF5(h5f)
	map = h5f.getNode("/map/map").read()
	map_mask = h5f.getNode("/map/map_mask").read()
	nx, ny = map.shape
	map = map.transpose()
	map_mask = map_mask.transpose()
	vmin, vmax = get_map_range(map[(map_mask>0.)], cam.log_sensitive, cmap_range, fraction)
	if cam.log_sensitive:
		vrange = [10.**vmin, 10.**vmax]
	else:
		vrange = [vmin, vmax]
	print "Colormap range is : ", vrange
	map = numpy.clip(map, vmin, vmax)

	colormap, vmin, vmax = get_Colormap(cmap, discrete, (vmin, vmax))
	
	map = (map - vmin) / (vmax - vmin)
	map = numpy.asarray(colormap(map)*255, dtype='i')
	map = map.reshape(nx*ny,4)
	R_band = Image.new("L",(nx,ny))
	R_band.putdata(map[:,0])
	G_band = Image.new("L",(nx,ny))
	G_band.putdata(map[:,1])
	B_band = Image.new("L",(nx,ny))
	B_band.putdata(map[:,2])
	map_mask = numpy.asarray(map_mask * 255, dtype='i')
	map_mask = map_mask.reshape(nx*ny)
	A_band = Image.new("L",(nx,ny))
	A_band.putdata(map_mask)
	out_img = Image.merge("RGBA", (R_band, G_band, B_band, A_band)).transpose(Image.FLIP_TOP_BOTTOM)
	if img_path is None:
		h5f.close()
		return out_img
	else:
		fname = "%s.png"%h5f.getNode("/name").read()
		fname = os.path.join(img_path, fname)
		print "Saving img into '%s'"%fname
		out_img.save(fname)
		h5f.close()
		return
#}}}

def get_Colormap(cmap, discrete, ran):#{{{
	vmin, vmax = ran
	if isinstance(cmap, Colormap):
		colormap = cmap
	else:
		colormap = pylab.cm.get_cmap(cmap)
		if discrete:
			ncols = int(round(vmax - vmin)) + 1
			colormap = LinearSegmentedColormap('my_cmap', colormap._segmentdata, ncols)
			vmin = vmin - 0.5
			vmax = vmax + 0.5
		return (colormap, vmin, vmax)
#}}}

def save_HDF5_to_plot(h5fname, img_path=None, axis_unit=None, map_unit=None, cmap="jet", cmap_range=None,\
		fraction=None, save_into_png=True, discrete=False):#{{{
	r"""
	Function that plots the map with axis + colorbar from an HDF5 file

	Parameters
	----------
	h5fname      : the name of the HDF5 file containing the map
	img_path     : the path in wich the plot img file is to be saved
	axis_unit    : a (length_unit_label, axis_scale_factor) tuple containing :
		 * the label of the u/v axes unit
		 * the scaling factor of the u/v axes unit, or a Unit instance
	map_unit     : a (map_unit_label, map_scale_factor) tuple containing :
		 * the label of the map unit
		 * the scaling factor of the map unit, or a Unit instance
	cmap         : a Colormap object or any default python colormap string
	cmap_range   : a [vmin, vmax] array for map values clipping (linear scale)
	fraction     : fraction of the total map values below the min. map range (in percent)
	save_into_png: whether the plot is saved into an png file or not (default True)
	discrete     : wheter the map values are discrete integer values (default False). for colormap

	"""
	h5f = tables.openFile(h5fname, 'r')
	cam = Camera.from_HDF5(h5f)
	b = cam.get_map_box()
	map = h5f.getNode("/map/map").read()
	map_unit_label = None
	if map_unit is not None:
		map_unit_label, map_scale_factor = map_unit
		if isinstance(map_scale_factor, Unit):
			try:
				d = h5f.getNode("/map/unit/dimensions").read()
				v = h5f.getNode("/map/unit/val").read()
			except:
				raise ValueError("map unit record not found in '%s' HDF5 file"%h5fname)
			mu = Unit(d, v)
			map_scale_factor = mu.express(map_scale_factor)

		if cam.log_sensitive:
			map = map + numpy.log10(map_scale_factor)
		else:
			map = map * map_scale_factor

	nx, ny = map.shape
	map = map.transpose()
	
	vmin, vmax = get_map_range(map, cam.log_sensitive, cmap_range, fraction)
	colormap, vmin, vmax = get_Colormap(cmap, discrete, (vmin, vmax))
	vrange = [vmin, vmax]
	if cam.log_sensitive:
		vrange = [10.**vmin, 10.**vmax]
	print "Colormap range is : ", vrange
	map = numpy.clip(map, vmin, vmax)

	uedges, vedges = cam.get_pixels_coordinates_edges()
	uaxis, vaxis, zaxis = cam.get_camera_axis()
	ulabel = 'u'
	vlabel = 'v'
	ax_dict={'x':0, 'y':1, 'z':2}
	for axname, axis in Camera.special_axes.items():
		if  (numpy.abs(uaxis) == numpy.abs(axis)).all():
			ulabel = axname
			uedges = uedges + cam.center[ax_dict[axname]]
			if (uaxis != axis).any():
				uedges = uedges[::-1]
			break
	for axname, axis in Camera.special_axes.items():
		if  (numpy.abs(vaxis) == numpy.abs(axis)).all():
			vlabel = axname
			vedges = vedges + cam.center[ax_dict[axname]]
			if (vaxis != axis).any():
				vedges = vedges[::-1]
			break

	uvaxis_unit_label = 'box size unit'
	if axis_unit is not None:
		uvaxis_unit_label, axis_scale_factor = axis_unit
		if isinstance(axis_scale_factor, Unit):
			try:
				d = h5f.getNode("/map/length_unit/dimensions").read()
				v = h5f.getNode("/map/length_unit/val").read()
			except:
				raise ValueError("length_unit record not found in '%s' HDF5 file"%h5fname)
			au = Unit(d, v)
			axis_scale_factor = au.express(axis_scale_factor)

		uedges = uedges * axis_scale_factor
		vedges = vedges * axis_scale_factor

	fig = pylab.figure()
	pylab.pcolor(uedges, vedges, map, cmap=colormap, vmin=vmin, vmax=vmax)
	pylab.xlabel("%s (%s)"%(ulabel, uvaxis_unit_label))
	pylab.xlim(uedges[0],uedges[-1])
	pylab.ylabel("%s (%s)"%(vlabel, uvaxis_unit_label))
	pylab.ylim(vedges[0],vedges[-1])
	pylab.gca().set_aspect('equal')
	
	# Pretty user-defined colorbar
	if cam.log_sensitive:
		fo = pylab.matplotlib.ticker.FormatStrFormatter("$10^{%d}$")
		offset = numpy.ceil(vmin)-vmin
		lo = pylab.matplotlib.ticker.IndexLocator(1.0,offset)
		cb = pylab.colorbar(ticks=lo,format=fo)
	else:
		if discrete:
			fo = pylab.matplotlib.ticker.FormatStrFormatter("%d")
			ncol = int(round(vmax-vmin))
			ti = numpy.linspace(vmin+0.5, vmax-0.5, ncol)
			cb = pylab.colorbar(format=fo, ticks=ti)
		else:
			cb = pylab.colorbar()

	
	if map_unit_label is not None:
		cb.set_label(map_unit_label)

	if img_path is None:
		h5f.close()
		return fig
	else:
		if save_into_png:
			fname = "%s.png"%h5f.getNode("/name").read()
			fname = os.path.join(img_path, fname)
			print "Saving plot into '%s'"%fname
			pylab.savefig(fname)
			h5f.close()
			return
#}}}
	
def save_HDF5_seq_to_img(h5f_iter, *args, **kwargs):#{{{
	"""
	fraction : fraction (percent) of the total value of the map above the returned vmin value
			   (default 1 %)
	"""
	one_is_enough = False

	if "fraction" in kwargs.keys():
		frac = kwargs["fraction"]
	else:
		frac = None

	if "cmap_range" in kwargs.keys():
		cmap_range = kwargs["cmap_range"]
		one_is_enough = True
	else:
		cmap_range = None

	vrange_seq = []
	for file in h5f_iter():
		h5f = tables.openFile(file, 'r')
		map = h5f.getNode("/map/map").read()
		map_mask = h5f.getNode("/map/map_mask").read()
		is_logscale = h5f.getNode("/camera/log_sensitive").read()
		h5f.close()
		vrange = get_map_range(map[(map_mask>0.)], is_logscale, cmap_range, frac)
		vrange_seq.append(vrange)
		if one_is_enough:
			break

	vrange_seq = numpy.array(vrange_seq)
	vrange = numpy.array([numpy.min(vrange_seq[:,0]), numpy.max(vrange_seq[:,1])])
	if is_logscale:
		vrange = 10.**vrange
	
	kwargs["cmap_range"] = vrange
	print "Colormap range is : ", vrange

	imglist=[]
	for h5fname in h5f_iter():
		imglist.append(save_HDF5_to_img(h5fname, *args, **kwargs))
	def img_iter():
		for img in imglist:
			yield img

	return img_iter
#}}}

def get_map_range(map, log_sensitive, cmap_range, fraction):#{{{
	"""
	Map range computation function. Computes the linear/log (according to the map values scaling) scale map range values
	of a given map :

	 * if a user-defined cmap_range is given, then it is used to compute the map range values
	 * if not, the map range values is computed from a fraction (percent) of the total value
	   of the map parameter. the min. map range value is defined as the value below which there
	   is a fraction of the map (default 1 %)


	Parameters
	----------
	map            : 2D map from wich the map range values are computed
	log_sensitive  : whether the map values are log-scaled or not (True or False)
	cmap_range     : user-defined map range values (linear scale)
	fraction       : fraction of the total map values below the min. map range (in percent)

	Returns
	-------
	map_range : [``float``, ``float``]
		the map range values [ min, max]

	"""
	if cmap_range is not None:
		vmin, vmax = cmap_range
		if log_sensitive:
			vmin = numpy.log10(vmin)
			vmax = numpy.log10(vmax)
		map_range = [vmin, vmax]
	else:
		values = map.ravel()
		if fraction is not None:
			frac = fraction / 100.0
		else:
			frac = 0.01
		values.sort()
		if log_sensitive:
			val = 10.**values
			cumval = numpy.cumsum(val)
			cumval = cumval / cumval[-1]
			mask = (cumval >= frac)
			fvalues = values[mask]
			map_range = [fvalues[0], values[-1]]
		else:
			map_range = [values[0], values[-1]]
	
	return map_range
#}}}

__all__ = ["save_map_HDF5",
		   "save_HDF5_to_plot",
		   "save_HDF5_to_img",
		   "save_HDF5_seq_to_img",
		   "get_Colormap",
		   "get_map_range"]
