# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
from ..view.widget_ids import WidgetIds as wid

class RamsesSimController:
	def __init__(self):
		self.ramses_look_dir = "./"
	
	
	def OnSelectRamsesDir(self,out_dir):
		"""
		Send a SearchValidOutputs request to the model
		and return the returned value
		"""
		return self.model.SearchValidOutputs(out_dir)


	def OnSelectIout(self, event):
		self.SelectRamsesOutput(event.GetSelection())

	def RefreshRamsesIoutList(self, event):#{{{
		"""
		Refresh the ioutput_list.
		- Send a SearchValidOutputs request to the RAMSES model (with a
		None output directory argument).
		- If the result is True, 
		"""
		WID = wid()
		if self.model.SearchValidOutputs(None):
			re = self.widgets[WID.EXPANDER_RAMSES]
			re.UpdateOuputList()
	#}}}
			

	def SelectRamsesOutput(self, iout_index, init_ramses_sim=False):#{{{
		"""
		Selects a RAMSES output within the list of available output of the
		current simulation directory.

		Sends a request to the model to select the given output and makes the view refresh itself afterwards.
		"""
		WID = wid()
		if self.model.SetRamsesOutput(iout_index, init_ramses_sim):
			self.widgets[WID.EXPANDER_RAMSES].SetRamsesOutput(iout_index)
			self.widgets[WID.RF_TAB].RefreshRegionSize()
	#}}}
