# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
import numpy
from pymses.filters import *
from ray_trace import ray_trace_amr 
from ..fft_projection.cmp_maps import MapProcessor


class RayTracer(MapProcessor):
	r"""
	RayTracer class

	Parameters
	----------
	ramses_output   : :class:`~pymses.sources.ramses.output.RamsesOutput`
		ramses output from which data will be read to compute the map
	field_list      : ``list`` of ``string``
		list of all the required AMR fields to read (see :meth:`~pymses.sources.ramses.output.RamsesOutput.amr_source`)

	"""
	def __init__(self, ramses_output, field_list):
		MapProcessor.__init__(self, None)
		self.ro = ramses_output
		self.fields_to_read = field_list
		self.lmin=self.ro.info["levelmin"]
		self.lmax=self.ro.info["levelmax"]

	def process(self, op, camera, surf_qty=False):
		r"""
		Map processing method : ray-tracing through data cube

		Parameters
		----------
		op              : :class:`~pymses.analysis.visualization.Operator`
			physical scalar quantity data operator
		camera          : :class:`~pymses.analysis.visualization.Camera`
			camera containing all the view params
		surf_qty        : ``boolean``
			whether the processed map is a surface physical quantity. If True, the map is divided by the surface of a camera pixel.
		
		"""
		# AMR DataSource preparation
		rlev = camera.get_required_resolution()
		source = self.ro.amr_source(self.fields_to_read)
		source.set_read_lmax(rlev)

		# Camera view area
		filter_box = camera.get_map_box()
		map_range = numpy.array([[filter_box.min_coords[0],filter_box.max_coords[0]],\
					 [filter_box.min_coords[1],filter_box.max_coords[1]]])
	
		# Camera map size
		nx_map, ny_map = camera.get_map_size()
		# Pixels edges coordinates
		xedges, yedges = camera.get_pixels_coordinates_edges()
		xcen = (xedges[1:]+xedges[:-1])/2.
		ycen = (yedges[1:]+yedges[:-1])/2.
		zmin = filter_box.min_coords[2]
		zmax = filter_box.max_coords[2]
		depth_max= zmax - zmin

		ray_origins = numpy.zeros((nx_map, ny_map, 3))
		ray_origins[:,:,0] = xcen[:, numpy.newaxis]
		ray_origins[:,:,1] = ycen[numpy.newaxis, :]
		ray_origins[:,:,2] = zmin
		ray_origins = ray_origins.reshape(nx_map * ny_map, 3)
		ray_vectors = numpy.zeros((nx_map*ny_map,3))
		ray_vectors[:,2]=1.0


		# Origin points + axis of the rays (in AMR grid coordinates : x, y, z)
		xform = camera.viewing_angle_transformation().inverse()
		ray_origins = xform.transform_points(ray_origins)
		ray_vectors = xform.transform_vectors(ray_vectors, ray_origins)

		# Data bounding box
		domain_bounding_box = camera.get_bounding_box()
	
		# Extended domain bounding box
		ext = numpy.sqrt(3.0) * 0.5**(self.lmin+1)
		domain_bounding_box.min_coords = numpy.amax([domain_bounding_box.min_coords - ext,[0.,0.,0.]], axis=0)
		domain_bounding_box.max_coords = numpy.amin([domain_bounding_box.max_coords + ext,[1.,1.,1.]], axis=0)
	
		# Data spatial filtering
		rsource = RegionFilter(domain_bounding_box, source)

		# Map initialisation
		maps = numpy.zeros((nx_map * ny_map, op.nscal_func()), dtype='d')
		for dset in rsource.iter_dsets():
			if op.is_max_alos():
				maps = numpy.max(numpy.array([maps, ray_trace_amr(dset, ray_origins, ray_vectors, depth_max, op, self.ro.info)]), axis=0)
			else:
				maps += ray_trace_amr(dset, ray_origins, ray_vectors, depth_max, op, self.ro.info)

		ifunc=0
		map_dict = {}
		S = camera.get_pixel_surface()
		for key, func in op.iter_scalar_func():
			if (op.is_max_alos()+surf_qty):
				map_dict[key] = maps[:,ifunc].reshape(nx_map, ny_map)
			else:
				map_dict[key] = S * maps[:,ifunc].reshape(nx_map, ny_map)
			ifunc+=1
		map = op.operation(map_dict)

		# Return log-scale map if the camera captors are log-sensitive
		if camera.log_sensitive:
			min_map = numpy.min(map[(map > 0.0)])
			numpy.clip(map, min_map, map.max(), out=map)
			map = numpy.log10(map)
	
		return map


__all__ = ["RayTracer"]
