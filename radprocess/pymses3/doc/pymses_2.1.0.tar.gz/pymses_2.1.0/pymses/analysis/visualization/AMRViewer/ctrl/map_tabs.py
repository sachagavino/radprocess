# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
from ..view.widget_ids import WidgetIds as wid

class MapTabController:#{{{

	timing_ms = 20 # Refreshing time interval
	
	def __init__(self):
		self.active_tab = None
		self.tab_time = 0

	def NotebookChangeTab(self, event):#{{{
		"""
		Changed notebook tab : update the name of the active tab
		"""
		WID = wid()
		tab_id = event.GetSelection()
		if tab_id == 0: # Ragion Finder tab
			self.active_tab = None
		else:
			self.active_tab = WID.TAB_NAME_LIST[tab_id-1]
	#}}}


	def TabMapWindowOnMouse(self, event):#{{{
		""" Handles mouse events coming from a MapWindow of any MapTab
		of the notebook (right panel of the view)
		"""
		WID = wid()
		win = event.GetEventObject()
		tab = self.widgets[WID.TAB_IDS[win.name]]
		
		# nothing to do if the window doesn't have a map to display
		if win.bitmap is None:
			return

		if event.Leaving():	# Leaving the window
			win.MoveCursor(None, None)	
			if win.rule_mode:
				win.FreezeOrigin(None, None)
		else:
			t = event.GetTimestamp()
			if ((event.Moving()+event.Dragging())*((t-self.tab_time) < MapTabController.timing_ms)): # Refreshment frequency
				return
			self.tab_time = t

#			if event.RightUp():
#			# Right click : UNSET behavior {{{
#				if win.rule_mode:
#					pass
#					#TODO
#			#}}}
			
			# Cursor movement : Pointer position of the event
			i, j = event.GetPosition()
			win.MoveCursor(i, j)

			if event.LeftDown():
			# Left button pressed : SET behavior {{{
				if win.rule_mode:
					win.FreezeOrigin(i, j)
			#}}}
			if event.LeftUp():
			# Left button released : UNSET behavior {{{
				if win.rule_mode:
					win.FreezeOrigin(None, None)
			#}}}

		if win.magnifier_mode: #Magnifier
			gle = self.widgets[WID.EXPANDER_GLASS]
			# Display a magnified zone of the map in the Magnifier window
			gl_img = win.GetMagnifierBoxImage()
			gle.SetGlassImage(gl_img)
			
			# Display physical quantity value under the cursor
			pos = win.GetMapCursorPosition()
			self.model.SetGlassCenter(pos)
			gle.RefreshPhysicalValue(win.name)
		if win.rule_mode: # Rule
			rule_dist = win.GetRuleDist()
			if self.model.SetRuleDist(rule_dist):
				ru = self.widgets[WID.EXPANDER_RULE]
				ru.RefreshRuleValue()
		tab.RefreshWholeTab()
	#}}}

	# Tool button click {{{
	def TabMapWindowRuleClick(self, event):
		self.TabMapWindowToolClick(event, "rule")

	def TabMapWindowMagnClick(self, event):
		self.TabMapWindowToolClick(event, "magnifier")
	
	def TabMapWindowToolClick(self, event, tool):
		"""
		Click on a tool button of any TabMap
		"""
		assert (tool in ["rule", "magnifier"]), "Unknown tool '%s'"%tool
		if self.active_tab is None:
			return
		WID = wid()

		# Get the clicked button + its id
		btn = event.GetEventObject()
		btn_id = btn.GetId()

		# Get the active tab
		tab = self.widgets[WID.TAB_IDS[self.active_tab]]

		if btn.GetToggle(): # tool toggled
			er = self.widgets[WID.EXPANDER_RULE]
			eg = self.widgets[WID.EXPANDER_GLASS]
			if tool == "rule": # Rule tool
				tab.EnableRule()
				# Expand rule Expander
				if er.IsCollapsed():
					er.Collapse(False)
				# Collapse magnifier Expander
				if not eg.IsCollapsed():
					eg.Collapse(True)
			elif tool == "magnifier": # magnifier tool
				tab.EnableMagnifier()
				# Expand magnifier Expander
				if eg.IsCollapsed():
					eg.Collapse(False)
				# Collapse rule Expander
				if not er.IsCollapsed():
					er.Collapse(True)
		
		else: # tool untoggled
			if tool == "rule":
				tab.DisableRule()
			elif tool == "magnifier":
				tab.DisableMagnifier()
	#}}}

	def TabMapWindowUpdateClick(self, event):#{{{
		"""
		Click on the update button of any TabMap
		"""
		WID = wid()
		# Get the active tab
		tab = self.widgets[WID.TAB_IDS[self.active_tab]]
		tab_name = tab.name

		if self.model.ro is not None:
			# Size of the tab window
			nx, ny = tab.GetWindowSize()

			# Update map
			self.model.UpdateTabMap(nx, self.active_tab)
			tab.UpdateTabImage()

#			tab.MoveCursor(u=None, v=None, w=None)
#			# Refresh cursor types on the tab window
#			tab.RefreshWindowCursor()

			tab.RefreshWholeTab(make_bitmap=True)
	#}}}


#}}}
