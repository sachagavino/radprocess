# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
from pymses.utils import constants as C
from pymses.analysis.visualization import Camera
from numpy import array, newaxis
from ramses import map_engine, MassWeightedDensityMapEngine
from region_finder import RegionFinderModel
from utils import get_appropriate_unit
import tables as T

class MapTabsModel:
	def __init__(self):
		self.map_engine_dict = {}

	def reset(self):#{{{
		self.tab_map_images = {}
		self.tab_map_arrays = {}
		self.glass_x = None
		self.glass_y = None
		self.rule_dist = None
	#}}}

	def UpdateTabMap(self, nxy, tab_name):#{{{
		cam = self.get_los_camera(nxy)
		if not tab_name in self.map_engine_dict.keys():
			self.map_engine_dict[tab_name] = map_engine(tab_name, self.ro)
		me = self.map_engine_dict[tab_name]
		d = me.MakeMaps(cam, {"los":cam})
		self.tab_map_images[tab_name] = d["los"]
		m = me.GetMapArrays()
		self.tab_map_arrays[tab_name] = m["los"]
	#}}}

	def GetTabImage(self, tab_name):
		return self.tab_map_images[tab_name]

	def SetGlassCenter(self, position):#{{{
		"""
		Sets the position of the magnifying glass center
		"""
		self.glass_x, self.glass_y = position
	#}}}

	def GetGlassValue(self, tab_name):
		map = self.tab_map_arrays[tab_name]
		if ((self.glass_x is None)+(self.glass_y is None)):
			return (None, None)
		else:
			val = map[self.glass_x, self.glass_y]
			mu = self.map_engine_dict[tab_name]
			value, unit = mu.GetAppropriateUnit(val)
			return (value, unit)

	def SetRuleDist(self, dist):
		if self.rule_dist == dist:
			return False
		else:
			self.rule_dist = dist
			return True

	def GetRuleValue(self):
		if self.rule_dist is None:
			return (0.0, "")
		else:
			size = self.rule_dist * self.region_size * self.length_unit
			if self.zoom_size is not None:
				size = size * self.zoom_size
			return get_appropriate_unit(size, RegionFinderModel.lunit_dict)

	def SaveLosCameraToHDF5(self, h5fname):#{{{
		h5f = T.openFile(h5fname, "w")
		cam = self.get_los_camera(256)
		cam.save_HDF5(h5f)
		h5f.close()
		return True
	#}}}
	
	def LoadLosCameraFromHDF5(self, h5fname):#{{{
		h5f = T.openFile(h5fname, "r")
		cam = Camera.from_HDF5(h5f)
		h5f.close()
		self.SetRegionSize(cam.region_size[0])
		uvect, vvect, losvect = cam.get_camera_axis()
		self.SetUVAxis(u=uvect, v=vvect)
		self.RefreshPoints()
		self.region_center = cam.center
		self.cameras["los"] = cam
		self.update_cross_center_coords()
	#}}}

	def get_los_camera(self, nxy):#{{{
		uaxis, vaxis = self.GetUVAxes()
		waxis = self.GetLosAxis()
		cc = self.region_center
		rs = self.region_size
		cam = Camera(center=cc, line_of_sight_axis=waxis, up_vector=vaxis, \
				region_size=[rs, rs], distance=(rs/2.), far_cut_depth=(rs/2.), \
				map_max_size=nxy)
		return cam
	#}}}

