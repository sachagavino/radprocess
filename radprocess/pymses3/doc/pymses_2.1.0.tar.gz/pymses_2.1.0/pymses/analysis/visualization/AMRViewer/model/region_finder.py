# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
from pymses.utils import constants as C
from pymses.analysis.visualization import Camera
from numpy import array, newaxis
from utils import get_appropriate_unit
from ramses import MassWeightedDensityMapEngine

class RegionFinderModel:
	
	lunit_dict = {'pc': C.pc, \
				  'kpc': C.kpc, \
				  'Mpc': C.Mpc, \
				  'Gpc':C.Gpc, \
				  'ly': C.ly, \
				  'au':C.au
				  }

	def __init__(self):
		self.length_unit = None

	def reset(self):#{{{
		print "Reset Region finder Model"
		self.cross_center = array([0.5, 0.5, 0.5])
		self.region_center = array([0.5, 0.5, 0.5])
		self.cameras = {'los':None, 'u':None, 'v':None}

		self.cursor_u = None
		self.cursor_v = None
		self.cursor_w = None
		
		self.SetRegionSize(1.0)
		self.SetZoomSize(None)
	#}}}

	def UpdateCursorUVWPosition(self, u, v, w):#{{{
		"""
		Update the (u, v, w) position of the cursor.
		"""
		cs = self.region_size
		if u is not None:
			self.cursor_u = u * cs
		else:
			self.cursor_u = None
		if v is not None:
			self.cursor_v = v * cs
		else:
			self.cursor_v = None
		if w is not None:
			self.cursor_w = w * cs
		else:
			self.cursor_w = None

		self.update_cross_center_coords()
	#}}}

	def UpdateRegionFinderMaps(self, nxys, zoom=False):#{{{
		self.update_cameras(nxys, zoom)
		self.me = MassWeightedDensityMapEngine(self.ro)

		self.axis_images = self.me.MakeMaps(self.cameras["los"], self.cameras)
	#}}}

	def GetAxisImages(self):
		return self.axis_images

	def GetCrossCenterUVW(self):#{{{
		u = self.cursor_u
		if u is None:
			u = 0.0
		v = self.cursor_v
		if v is None:
			v = 0.0
		w = self.cursor_w
		if w is None:
			w = 0.0
		uvw_center = array([u, v, w])
		return uvw_center
	#}}}

	def update_cross_center_coords(self):#{{{
		uvw_center = self.GetCrossCenterUVW()
		self.cross_center = self.cameras["los"].deproject_points(uvw_center[newaxis,:])[0]
	#}}}
	
	def update_cameras(self, nxys, zoom):#{{{
		uaxis, vaxis = self.GetUVAxes()
		waxis = self.GetLosAxis()

		self.region_center[:] = self.cross_center[:]
		cc = self.region_center

		if (zoom * (self.zoom_size is not None)):
			self.region_size = self.region_size * self.zoom_size
		rs = self.region_size

		self.cameras['los'] = Camera(center=cc, line_of_sight_axis=waxis, up_vector=vaxis, region_size=[rs, rs], \
					distance=(rs/2.), far_cut_depth=(rs/2.), map_max_size=nxys["los"])
		self.cameras['u'] = Camera(center=cc, line_of_sight_axis=uaxis, up_vector=vaxis, region_size=[rs, rs], \
					distance=(rs/2.), far_cut_depth=(rs/2.), map_max_size=nxys["u"])
		self.cameras['v'] = Camera(center=cc, line_of_sight_axis=-vaxis, up_vector=waxis, region_size=[rs, rs], \
					distance=(rs/2.), far_cut_depth=(rs/2.), map_max_size=nxys["v"])
	#}}}

	def SetRegionSize(self, rsize):#{{{
		self.region_size = rsize
	#}}}
	
	def SetRegionSizeUnit(self, unit):#{{{
		self.length_unit = unit
	#}}}
	
	def SetZoomSize(self, s):#{{{
		self.zoom_size = s
	#}}}

	def GetCrossCenter(self):#{{{
		return self.cross_center
	#}}}

	def GetRegionSize(self):#{{{
		if self.ro is None:
			return (0.0, "")
		else:
			size = self.region_size * self.length_unit
			if self.zoom_size is not None:
				size = size * self.zoom_size
			return get_appropriate_unit(size, RegionFinderModel.lunit_dict)
	#}}}

