# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
import wx
from widget_ids import WidgetIds as wid
from utils import get_icon
from axes3d import Axes3D
from glass import MagGlass
from map_tabs import GenericTabMapWindow

class Expander(wx.CollapsiblePane):#{{{
	def __init__(self, parent, id, title, model, controller, is_collapsed=True):
		wx.CollapsiblePane.__init__(self, parent, id, label=title, style= wx.CP_DEFAULT_STYLE | wx.CP_NO_TLW_RESIZE)

		self.model = model
		self.controller = controller
		
		pane = self.GetPane()
		sizer = wx.BoxSizer(wx.VERTICAL)
		pane.SetSizer(sizer)
		
		box = wx.StaticBox(pane, wx.ID_ANY)
		boxsizer = wx.StaticBoxSizer(box, wx.VERTICAL)
		inpane = wx.Panel(pane, wx.ID_ANY)
		self.insizer = wx.BoxSizer(wx.VERTICAL)
		inpane.SetSizer(self.insizer)
		
		self.make_content(inpane)
		
		boxsizer.Add(inpane, 0, wx.ALL|wx.EXPAND, 2)
		sizer.Add(boxsizer, 0, wx.EXPAND|wx.LEFT, 10)
		self.Collapse(is_collapsed)

	def add_descr_label(self, parent, text):
		label = wx.StaticText(parent, wx.ID_ANY, "%s :"%text)
		self.insizer.Add(label, 0, wx.ALIGN_LEFT)
		
	def add_centered_item(self, item, is_expanded=False):
		if is_expanded:
			self.insizer.Add(item, 0, wx.LEFT|wx.EXPAND, 5)
		else:
			self.insizer.Add(item, 0, wx.LEFT|wx.ALIGN_CENTER_HORIZONTAL, 5)


	def make_content(self, parent, sizer):
		raise NotImplementedError()

	def reset(self):
		raise NotImplementedError()

#}}}


class RamsesExpander(Expander):#{{{
	def __init__(self, parent, model, controller):
		WID = wid()
		Expander.__init__(self, parent, WID.EXPANDER_RAMSES, "RAMSES simulation", model, controller, is_collapsed=True)

	def make_content(self, parent):#{{{
		WID = wid()
		self.add_descr_label(parent, "RAMSES outputs directory")
		self.out_dir_ctrl = wx.TextCtrl(parent, WID.ANY)
		self.add_centered_item(self.out_dir_ctrl, is_expanded=True)

		self.add_descr_label(parent, "Output number")
		p = wx.Panel(parent, WID.ANY)
		bs = wx.BoxSizer(wx.HORIZONTAL)
		p.SetSizer(bs)
		self.iout_cb = wx.ComboBox(p, WID.ANY, size=(80,-1), style=wx.CB_READONLY)
		iout_cb_refbtn = wx.BitmapButton(p, WID.ANY, wx.Bitmap(get_icon("update.png")))
		iout_cb_refbtn.SetToolTip(wx.ToolTip("Update output list"))
		bs.Add(self.iout_cb, 0, wx.RIGHT | wx.ALIGN_CENTER_VERTICAL | wx.ALIGN_RIGHT, 5)
		bs.Add(iout_cb_refbtn, 0, wx.LEFT | wx.ALIGN_CENTER_VERTICAL | wx.ALIGN_LEFT, 5)

		# Bind button to controller method
		self.iout_cb.Bind(wx.EVT_COMBOBOX, self.controller.OnSelectIout)
		iout_cb_refbtn.Bind(wx.EVT_BUTTON, self.controller.RefreshRamsesIoutList)


		self.add_centered_item(p)

		self.add_descr_label(parent, "Output time")
		self.out_time_label = wx.StaticText(parent, WID.ANY, "---")
		self.add_centered_item(self.out_time_label)
	#}}}

	def reset(self):
		pass

	def SelectRamsesDir(self, out_dir):#{{{
		"""
		Send a request to select a Ramses output directory to the controller
		and updates the view if the returned result is True
		"""
		if self.controller.OnSelectRamsesDir(out_dir): # This directory is valid, it contains at least 1 Ramses output
			# Open the expander if previously closed
			if self.IsCollapsed():
				self.Collapse(False)

			# Display the out_dir in the appropriate text field
			self.out_dir_ctrl.ChangeValue(out_dir)

			# Output number list update
			self.UpdateOuputList()
			
			self.controller.SelectRamsesOutput(0, init_ramses_sim=True)
			return True
		return False
	#}}}

	def UpdateOuputList(self):#{{{
		"""
		Display the output list in the ComboBox and select the first item
		"""
		ilist = self.model.GetvalidOutputsList()
		ilist_string = ["%i"%i for i in ilist]
		self.iout_cb.SetItems(ilist_string)
	#}}}

	def SetRamsesOutput(self, iout_index):#{{{
		"""
		Sets the selected Ramses output number in the Combobox and refresh
		the output time.

		iout_index  ---  chosen output number index
		"""
		self.iout_cb.Select(iout_index)
		time, unit = self.model.GetOutputTime()
		self.out_time_label.SetLabel("%.2f %s"%(time, unit))
	#}}}
#}}}


class LineOfSightExpander(Expander):#{{{
	def __init__(self, parent, model, controller):
		WID = wid()
		Expander.__init__(self, parent, WID.EXPANDER_LOS, "Line-of-sight axis", model, controller, is_collapsed=False)

	def make_content(self, parent):#{{{
		WID = wid()
		self.add_descr_label(parent, "3D-view")
		self.a3d = Axes3D(parent)
		self.add_centered_item(self.a3d)
		self.a3d.Bind(wx.EVT_MOUSE_EVENTS, self.controller.A3dOnMouse)
		self.a3d.Bind(wx.EVT_KEY_DOWN, self.controller.A3dOnKeyPress)
		self.a3d.Bind(wx.EVT_KEY_UP, self.controller.A3dOnKeyRelease)

		self.add_descr_label(parent, "Axis shortcuts")
		axis_up_toolbar = wx.ToolBar(parent, WID.ANY, style=wx.TB_HORIZONTAL | wx.NO_BORDER)
		axis_up_toolbar.AddSimpleTool(WID.LOS_TOOL_X, wx.Bitmap(get_icon("x-axis.png")), 'View along the X axis')
		axis_up_toolbar.AddSeparator()
		axis_up_toolbar.AddSimpleTool(WID.LOS_TOOL_Y, wx.Bitmap(get_icon("y-axis.png")), 'View along the Y axis')
		axis_up_toolbar.AddSeparator()
		axis_up_toolbar.AddSimpleTool(WID.LOS_TOOL_Z, wx.Bitmap(get_icon("z-axis.png")), 'View along the Z axis')
		axis_up_toolbar.AddSeparator()
		axis_up_toolbar.AddSimpleTool(WID.LOS_TOOL_ROT_LEFT, wx.Bitmap(get_icon("rotate_left.png")), 'Rotate the axes to the left')
		axis_up_toolbar.AddSeparator()
		axis_up_toolbar.AddSimpleTool(WID.LOS_TOOL_ROT_TOP, wx.Bitmap(get_icon("rotate_top.png")), 'Rotate the axes to the top')
		axis_up_toolbar.Realize()
		axis_down_toolbar = wx.ToolBar(parent, WID.ANY, style=wx.TB_HORIZONTAL | wx.NO_BORDER)
		axis_down_toolbar.AddSimpleTool(WID.LOS_TOOL_MX, wx.Bitmap(get_icon("x-axis.png")), 'View along the -X axis')
		axis_down_toolbar.AddSeparator()
		axis_down_toolbar.AddSimpleTool(WID.LOS_TOOL_MY, wx.Bitmap(get_icon("y-axis.png")), 'View along the -Y axis')
		axis_down_toolbar.AddSeparator()
		axis_down_toolbar.AddSimpleTool(WID.LOS_TOOL_MZ, wx.Bitmap(get_icon("z-axis.png")), 'View along the -Z axis')
		axis_down_toolbar.AddSeparator()
		axis_down_toolbar.AddSimpleTool(WID.LOS_TOOL_ROT_RIGHT, wx.Bitmap(get_icon("rotate_right.png")), 'Rotate the axes to the right')
		axis_down_toolbar.AddSeparator()
		axis_down_toolbar.AddSimpleTool(WID.LOS_TOOL_ROT_BOTTOM, wx.Bitmap(get_icon("rotate_bottom.png")), 'Rotate the axes to the bottom')
		axis_down_toolbar.Realize()
		self.add_centered_item(axis_up_toolbar, is_expanded=True)
		self.add_centered_item(axis_down_toolbar, is_expanded=True)
		
		self.add_descr_label(parent, "Line-of-sight coordinates")
		coord_panel = wx.Panel(parent, WID.ANY)
		grid_sizer = wx.FlexGridSizer(3,2)
		coord_panel.SetSizer(grid_sizer)
		los_x_label =  wx.StaticText(coord_panel, WID.ANY, "x :")
		los_y_label =  wx.StaticText(coord_panel, WID.ANY, "y :")
		los_z_label =  wx.StaticText(coord_panel, WID.ANY, "z :")
		self.los_x = wx.TextCtrl(coord_panel, WID.ANY, style=wx.TE_READONLY, size=(80,-1))
		self.los_y = wx.TextCtrl(coord_panel, WID.ANY, style=wx.TE_READONLY, size=(80,-1))
		self.los_z = wx.TextCtrl(coord_panel, WID.ANY, style=wx.TE_READONLY, size=(80,-1))
		grid_sizer.AddMany([(los_x_label, 0, wx.ALIGN_CENTER_VERTICAL | wx.ALIGN_RIGHT),\
							(self.los_x, 0), \
							(los_y_label, 0, wx.ALIGN_CENTER_VERTICAL | wx.ALIGN_RIGHT), \
							(self.los_y, 0), \
							(los_z_label, 0, wx.ALIGN_CENTER_VERTICAL | wx.ALIGN_RIGHT), \
							(self.los_z, 0)])
		self.add_centered_item(coord_panel)

		# Binding toolbar events to controller method
		axis_up_toolbar.Bind(wx.EVT_TOOL, self.controller.OnShortcutAxis, id=WID.LOS_TOOL_X)
		axis_down_toolbar.Bind(wx.EVT_TOOL, self.controller.OnShortcutAxis, id=WID.LOS_TOOL_MX)
		axis_up_toolbar.Bind(wx.EVT_TOOL, self.controller.OnShortcutAxis, id=WID.LOS_TOOL_Y)
		axis_down_toolbar.Bind(wx.EVT_TOOL, self.controller.OnShortcutAxis, id=WID.LOS_TOOL_MY)
		axis_up_toolbar.Bind(wx.EVT_TOOL, self.controller.OnShortcutAxis, id=WID.LOS_TOOL_Z)
		axis_down_toolbar.Bind(wx.EVT_TOOL, self.controller.OnShortcutAxis, id=WID.LOS_TOOL_MZ)
		axis_up_toolbar.Bind(wx.EVT_TOOL, self.controller.OnShortcutAxis, id=WID.LOS_TOOL_ROT_LEFT)
		axis_down_toolbar.Bind(wx.EVT_TOOL, self.controller.OnShortcutAxis, id=WID.LOS_TOOL_ROT_RIGHT)
		axis_up_toolbar.Bind(wx.EVT_TOOL, self.controller.OnShortcutAxis, id=WID.LOS_TOOL_ROT_TOP)
		axis_down_toolbar.Bind(wx.EVT_TOOL, self.controller.OnShortcutAxis, id=WID.LOS_TOOL_ROT_BOTTOM)
	#}}}

	def RefreshAxes3D(self):#{{{
		"""
		Line-of-sight expander content refresh method

		mouse_in  --- whether the mouse is in the 3D window or not
		"""
		# Axes3D refresh
		self.a3d.SetUVPoints(self.model.GetUVPoints())
		self.a3d.Refresh()

		# Line-of-sight x/y/z coordinates update
		los = self.model.GetLosAxis()
		self.los_x.ChangeValue("%.6f"%los[0])
		self.los_y.ChangeValue("%.6f"%los[1])
		self.los_z.ChangeValue("%.6f"%los[2])
	#}}}

	def GetAxes3d(self):#{{{
		return self.a3d
	#}}}

	def reset(self):#{{{
		self.a3d.SetCtrlDown(False)
		self.a3d.SetClickDown(False)
		self.a3d.SetMouseIn(False)
		self.a3d.SetCursorPosition(None, None)
		self.a3d.UpdateCursor()
		self.RefreshAxes3D()
	#}}}
#}}}

class MagGlassExpander(Expander):#{{{
	def __init__(self, parent, model, controller):
		WID = wid()
		Expander.__init__(self, parent, WID.EXPANDER_GLASS, "Magnifier", model, controller, is_collapsed=True)

	def make_content(self, parent):#{{{
		WID = wid()
		self.add_descr_label(parent, "Magnifying glass")
		self.glass = MagGlass(parent)
		self.add_centered_item(self.glass)
		
		self.add_descr_label(parent, "Value")
		self.glass_value = wx.StaticText(parent, WID.GLASS_VAL, "        ---        ")
		self.add_centered_item(self.glass_value)
		
		self.add_descr_label(parent, "Magnification factor")
		self.mag_factor_list = [2, 4, 5, 8, 10, 20]
		mag_factor_cb = wx.ComboBox(parent, WID.ANY, size=(80,-1), style=wx.CB_READONLY)
		mag_factor_cb.AppendItems(["x %i"%f for f in self.mag_factor_list])
		mag_factor_cb.Select(3)
		mag_factor_cb.Bind(wx.EVT_COMBOBOX, self.on_change_mag_factor)
		self.add_centered_item(mag_factor_cb)
	#}}}
	
	def reset(self):
		pass

	def SetGlassImage(self, pil_image):#{{{
		if pil_image is None:
			self.glass.bitmap = None
		else:
			nx, ny = self.glass.GetSize()
			img = wx.EmptyImage(nx, ny)
			rpil = pil_image.resize((nx, ny))
			img.SetData(rpil.convert("RGB").tostring())
			img.SetAlphaData(rpil.tostring()[3::4])
			self.glass.bitmap = img.ConvertToBitmap()
		self.glass.Refresh()
	#}}}

	def RefreshPhysicalValue(self, tab_name):#{{{
		"""
		"""
		val, unit = self.model.GetGlassValue(tab_name)
		if ((val is None)+(unit is None)):
			self.glass_value.SetLabel("        ---        ")
		else:
			self.glass_value.SetLabel("%.2e %s"%(val, unit))
	#}}}

	def on_change_mag_factor(self, event):#{{{
		mgf = self.mag_factor_list[event.GetSelection()]
		nx, ny = self.glass.GetSize()
		GenericTabMapWindow.mag_box_size = nx / mgf
		MagGlass.mag_factor = mgf
	#}}}

	
#}}}

class RuleExpander(Expander):#{{{
	def __init__(self, parent, model, controller):
		WID = wid()
		Expander.__init__(self, parent, WID.EXPANDER_RULE, "Rule", model, controller, is_collapsed=True)

	def make_content(self, parent):
		WID = wid()
		self.add_descr_label(parent, "Measured distance")
		panel = wx.Panel(parent, WID.ANY)
		s = wx.BoxSizer(wx.HORIZONTAL)
		panel.SetSizer(s)

		rule_value_label = wx.StaticText(panel, WID.ANY, "d = ")
		self.rule_value = wx.TextCtrl(panel, WID.RULE_VALUE, "", size=(60,-1), style=wx.TE_READONLY)
		self.rule_unit = wx.StaticText(panel, WID.RULE_UNIT, "", size=(50,-1))
		s.Add(rule_value_label, 0, wx.ALIGN_CENTER_VERTICAL | wx.ALIGN_RIGHT)
		s.Add(self.rule_value, 0)
		s.Add(self.rule_unit, 0, wx.ALIGN_CENTER_VERTICAL | wx.ALIGN_LEFT)
		self.add_centered_item(panel)

	def RefreshRuleValue(self):#{{{
		"""
		"""
		val, unit = self.model.GetRuleValue()
		if ((val==0.0)+(unit is None)):
			self.rule_value.ChangeValue("")
		else:
			self.rule_value.ChangeValue("%.2f"%val)
			self.rule_unit.SetLabel("%s"%unit)
	#}}}


	def reset(self):
		pass
#}}}

__all__ = ["RamsesExpander", "LineOfSightExpander", "MagGlassExpander", "RuleExpander"]
