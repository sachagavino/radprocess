# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
import numpy as N
from pymses.filters import *
from pymses.core import Source
from convolution_kernels import *
from ..camera import ExtendedCamera, CameraFilter
from map_bin2d import histo2D
from ..operator import *
import types



class MapProcessor:#{{{
	r"""
	Map-processing generic class

	"""
	def __init__(self, source):
		self.source = source

	def _surf_qty_map(self, camera, map):
		S = camera.get_pixel_surface()
		return map / S

	def process(self, op, camera, surf_qty=False):#{{{
		raise NotImplementedError()
#		source = self.source
#
#		if convol_kernel is None:
#			c = camera
#	
#		# Camera view area
#		filter_box = c.get_map_box()
#		map_range = N.array([[filter_box.min_coords[0],filter_box.max_coords[0]],\
#					 [filter_box.min_coords[1],filter_box.max_coords[1]]])
#
#		# Camera map size
#		nx_map, ny_map = c.get_map_size()
#
#		# Map coordinates edges
#		edges = c.get_pixels_coordinates_edges()
#
#		# Data bounding box
#		domain_bounding_box = c.get_bounding_box()
#	
#		# Data spatial filtering
#		region_source = RegionFilter(domain_bounding_box, self.source)
#	
#		# Sets the max. required read AMR level
#		region_source.set_read_lmax(c.get_required_resolution())
#
#		# Map processing (histogram)
#		print "Processing map (2D-histogram)"
#		map = None
#		for dset in region_source.iter_dsets():
#			pts_uv, depth = c.project_points(dset.points)
#			if pts_uv.shape[0]==0:
#				continue
#			map0 = N.histogram2d(pts_uv[:,0], pts_uv[:,1], bins=[nx_map, ny_map], \
#					range=map_range, weights=op(dset))[0]
#			if map is None:
#					map = map0
#			else:
#				map = map + map0
#
#		if surf_qty:
#			map = self._surf_qty_map(c, map)
#
#		# Return log-scale map if the camera captors are log-sensitive
#		if camera.log_sensitive:
#			min_map = N.min(map[(map > 0.0)])
#			N.clip(map, min_map, map.max(), out=map)
#			map = N.log10(map)
#	
#		return map
##}}}
#}}}

class MapFFTProcessor(MapProcessor):#{{{
	r"""
	MapFFTProcessor class

	Parameters
	----------
	source : ``Source``
		data source
	info   : ``dict``
		RamsesOutput info dict.

	"""
	def __init__(self, source, info, ker_conv=None, pre_flatten=False):
		if source.get_source_type() == Source.AMR_SOURCE:
			so = CellsToPoints(source)
		else:
			so = ExtendedPointFilter(source)
		MapProcessor.__init__(self, so)
		self.info = info
		if ker_conv is None:
			max_ker_size = 0.5**info["levelmin"]
			self.convol_kernel = GaussSplatterKernel(max_size=max_ker_size)
		else:
			self.convol_kernel = ker_conv
		self.pre_flatten = pre_flatten
		self.so = None


	def process(self, op, camera, surf_qty=False):
		"""Map processing method

		Parameters
		----------
		op              : :class:`~pymses.analysis.visualization.Operator`
			physical scalar quantity data operator
		camera          : :class:`~pymses.analysis.visualization.Camera`
			camera containing all the view params
		surf_qty        : ``boolean``
			whether the processed map is a surface physical quantity. If True, the map is divided by the surface of a camera pixel.

		Returns
		-------
		map : ``array``
			FFT-convoluted processed map

		"""
		ext_size = self.convol_kernel.max_size
		if self.pre_flatten:
			if self.so is None:
				self.so = CameraFilter(self.source, camera, ext_size).flatten()
		else:
			self.so = CameraFilter(self.source, camera, ext_size)
		
		region_level = camera.get_region_size_level()
		cs = 1./2**region_level

		# Map initial value
		nx, ny = camera.get_map_size()
		map = N.zeros((nx, ny))

		# Map processing (FFT convolution)
		print "Processing map dict. (kernel size by kernel size 2D binning)"
		map_dict = {}
		maps = {}
		for key, func in op:
			map_dict[key] = {}
			maps[key] = N.zeros((nx, ny))
		cam_dict = {}
		big_cells = []
		for ds in self.so:
			dset = ds.copy()
			if dset.npoints == 0: # No point in dset => fetch next dataset
				print "No interesting point in this dataset"
				continue
			print "npoints = %i"%dset.npoints

			# Sizes of the points
			sizes = self.convol_kernel.get_size(dset)

			# Big cells => straightforward summation
			mask = (sizes > cs/2.**2)# *4., *2., /2., /4., /8 ?
			big_cells_dset = dset.filtered_by_mask(mask)
			if big_cells_dset.npoints > 0:
				big_cells.append(big_cells_dset)

			# Small cells => FFT processing
			mask = (mask==False)
			small_cells_dset = dset.filtered_by_mask(mask)
			if small_cells_dset.npoints == 0:
				continue
			sizes = self.convol_kernel.get_size(small_cells_dset)
			
			# Get projected (u,v,w) coordinates of the dataset points
			pts, w = camera.project_points(dset.points[mask])
			
			# Weights fields
			weights = {}
			for key, func in op:
				weights[key] = func(small_cells_dset)

			# Map 2D binning
			for size in N.unique(sizes):# Level-by-level cell processing
				mask = (size==sizes)

				w = dict.fromkeys(weights)
				for key, func in op:
					w[key] = weights[key][mask]
				if size not in cam_dict.keys():# New size => get a new Camera
					r = N.ones((2,3))*size
					r[0,:] = -r[0,:]
					# Convolution kernel = gaussian type : extend the region by 3*sigma 
					# to get 99% of the gaussian into the extended region (anti-periodic effect)
					if isinstance(self.convol_kernel, GaussSplatterKernel):
						r = 3. * r
					cam_dict[size] = ExtendedCamera(camera, r)

				c = cam_dict[size]
				# Camera view area
				filter_box = c.get_map_box()
				map_range = N.array([[filter_box.min_coords[0],filter_box.max_coords[0]], \
									 [filter_box.min_coords[1],filter_box.max_coords[1]], \
									 [filter_box.min_coords[2],filter_box.max_coords[2]]])

				# Camera map size
				nx_map, ny_map = c.get_map_size()

				# 2D Binning of the dataset points with a dict. of weights.
				map0 = histo2D(pts[mask,:], [nx_map, ny_map], map_range, w)
				for key, func in op:
					ma = map_dict[key]
					if size in ma.keys():
						ma[size] = ma[size] + map0[key]
					else:
						ma[size] = map0[key]

		for key, md in map_dict.iteritems():
			if len(md.keys())>0:
				maps[key] += self.convol_kernel.convol_fft(md, cam_dict)
		del map_dict

		# Large points direct gaussian kernel addition
		if len(big_cells)>0:
			dset_bcells = big_cells[0].concatenate(big_cells)
			print "Big points : %i"%dset_bcells.npoints

			# Map edges/center coordinates
			xedges, yedges = camera.get_pixels_coordinates_edges()
			xc = (xedges[1:] + xedges[:-1])/2.
			yc = (yedges[1:] + yedges[:-1])/2.
			b = camera.get_map_box()
			zmin = b.min_coords[2]
			zmax = b.max_coords[2]

			# u/v/w Coordinates of the points
			uv, w = camera.project_points(dset_bcells.points)
			# Sizes of the points
			sizes = self.convol_kernel.get_size(dset_bcells)
			
			f = N.abs(w - (zmin+zmax)/2.) / (zmax-zmin) - 0.5
			weights_fact = win_func(f)

			for key, func in op:
				weights = func(dset_bcells)
				for i in range(uv.shape[0]):
					s = sizes[i]
					m = self.convol_kernel.ker_func((xc-uv[i,0]), (yc-uv[i,1]), s)
					maps[key] += m * weights[i] * weights_fact[i]
		
		# Final Operator process
		nproc = True
		for m in maps.values():
			nproc *= (m == 0.0).all()
		if nproc:
			return map

		map = map + op.operation(maps)
		del maps
		
		if surf_qty:
			map = self._surf_qty_map(camera, map)
		
		# Return log-scale map if the camera captors are log-sensitive
		if camera.log_sensitive:
			if (map>0.0).any():
				min_map = N.min(map[(map > 0.0)])
				N.clip(map, min_map, map.max(), out=map)
				map = N.log10(map)
	
		return map
	#}}}


def win_func(x, l=0.1, c=9.):
	y = N.zeros_like(x)
	y[(x<=0.)]=1.0

	# exp 1
	mask = ((x<=l/2.)*(x>0.))
	y[mask] = 0.5 + 0.5 * (1.0- N.exp((x[mask] - l/2.)/(l/(2.*c)))) / (1.0-N.exp(-c))

	# exp 2
	mask = ((x<=l)*(x>l/2.))
	y[mask] = 0.5 - 0.5 * (1.0- N.exp(-(x[mask] - l/2.)/(l/(2.*c)))) / (1.0-N.exp(-c))

	return y


__all__ = ["MapFFTProcessor"]
