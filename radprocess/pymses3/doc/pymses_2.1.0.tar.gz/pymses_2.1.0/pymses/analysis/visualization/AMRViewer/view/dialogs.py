# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
import wx
from os.path import abspath, basename
import tables as T

class RamsesSimOutputDialog(wx.DirDialog):#{{{
	"""
	RamsesSimOutputDialog is a DirDialog which allows the user to define
	a Ramses simulation outputs directory.
	"""
	def __init__(self, parent, ramses_expander):
		wx.DirDialog.__init__(self, parent, "Choose a RAMSES outputs directory", style=wx.DD_DEFAULT_STYLE, defaultPath=abspath("./"))
		self.ramses_expander = ramses_expander


	def run(self):#{{{
		if self.ShowModal() == wx.ID_OK: # The user selected a directory
			out_dir = self.GetPath()
			if not self.ramses_expander.SelectRamsesDir(out_dir): # This is not a valid RAMSES outputs dir.
				message = "No output found in the directory :\n\n%s"%out_dir
				dial = wx.MessageDialog(self, message, 'Warning', wx.OK | wx.ICON_EXCLAMATION)
				dial.ShowModal()
		self.Destroy()
	#}}}

#}}}


class CameraHDF5FileDialog(wx.FileDialog):#{{{
	def __init__(self, parent, controller, isTypeOpen=False):#{{{
		self.ctrl = controller
		self.load = isTypeOpen
		wildcard = "Camera HDF5 files (*.h5)|*.h5"
		if isTypeOpen:
			wx.FileDialog.__init__(self, parent, "Choose a camera HDF5 file", abspath("./"), "", wildcard, style=wx.FD_OPEN)
		else:
			wx.FileDialog.__init__(self, parent, "Choose a camera HDF5 file", abspath("./"), "camera.h5", wildcard, style=wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT)
	#}}}

	def run(self):#{{{
		if self.ShowModal() == wx.ID_OK: # The user selected a Camera HDF5 file
			path = self.GetPath()
			if not self.load:
				fname = basename(path)
				ext = fname[-3:]
				if ext != ".h5":
					path = "%s.h5"%path
				# Save camera into HDF5 file
				if self.ctrl.SaveLosCameraToHDF5(path):
					message = "Camera parameters correctly saved into file :\n\n%s"%path
					dial = wx.MessageDialog(self, message, 'Saved camera', wx.OK | wx.ICON_INFORMATION)
					dial.ShowModal()
			else:
				# Load Camera from HDF5 file
				self.ctrl.LoadLosCameraFromHDF5(path)
		self.Destroy()
	#}}}

#}}}
