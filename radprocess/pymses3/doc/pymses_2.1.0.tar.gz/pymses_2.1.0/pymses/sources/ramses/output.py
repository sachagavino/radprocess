# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
r"""
:mod:`pymses.sources.ramses.output` --- RAMSES output package
-------------------------------------------------------------

"""
import info, filename_utils, octree, particles, sources

class RamsesOutput(object):
	r"""
	RAMSES output class

	Parameters
	----------
	output_repos : ``string``
		path of the RAMSES output repository, containing all the simulation outputs
	iout         : ``int``
		output number

	Examples
	--------

		>>> ro = RamsesOutput("/data/Aquarius/outputs", 193)
	
	"""
	def __init__(self, output_repos, iout):
		r"""
		Build a RamsesOutput object from an output repository path and the number of the output.

		"""
		self.output_repos = output_repos
		self.iout = iout

		# List all the available files
		self.output_files = filename_utils.output_files_dict(output_repos, iout)

		# Read the .info file
		self.info = info.read_ramses_info_file(
			filename_utils.info_filename(output_repos, iout) )

		# Retrieve the domain decomposition
		self.dom_decomp = self.info["dom_decomp"]
		self.ncpu = self.info["ncpu"]

	def amr_source(self, amr_read_fields):
		r"""
		Return a RamsesAmrSource, able to read a set of amr fields


		Parameters
		----------
		amr_read_fields : ``list`` of ``strings``
			list of AMR data fields that needed to be read
		
		Returns
		-------
		ramses_amr_source : :class:`~pymses.sources.ramses.sources.RamsesAmrSource`
			RAMSES AMR data source
		
		"""
		reader_list = [
				octree.RamsesOctreeReader(self.output_repos, self.iout, 
					icpu, amr_read_fields)
				for icpu in range(1, self.ncpu+1) ]

		return sources.RamsesAmrSource(reader_list, self.dom_decomp)
	


	def particle_source(self, part_read_fields):
		r"""
		Return a RamsesParticleSource, able to read a set of user-defined particle data fields.


		Parameters
		----------
		part_read_fields : ``list`` of ``strings``
			list of particle data fields that needed to be read
		
		Returns
		-------
		ramses_part_source : :class:`~pymses.sources.ramses.sources.RamsesParticleSource`
			RAMSES particle data source
		
		"""
		reader_list = [
				particles.RamsesParticleReader(self.output_repos, self.iout, 
					icpu, part_read_fields, self.info["boxlen"])
				for icpu in range(1, self.ncpu+1) ]

		return sources.RamsesParticleSource(reader_list, self.dom_decomp)



__all__ = ["RamsesOutput"]
