# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
import numpy

import info, tree_utils, filename_utils
from amr import read_ramses_amr_file
from amrdata import read_ramses_amr_data_file
from pymses.core import Dataset, PointDataset


class RamsesOctreeDataset(Dataset):
	r"""
	RAMSES octree dataset class

	contains all the relevant information about the AMR tree structure

	"""
	def __init__(self, amr_dicts):
		self.amr_header, self.amr_struct = amr_dicts
		Dataset.__init__(self)


	def get_cell_centers(self):
		r"""
		Returns
		-------
		cell_centers : ``array``
			AMR cell center coordinates array

		"""
		# Compute the cell centers
		cell_centers = tree_utils.cell_centers_from_grid_centers(
				self.amr_struct["grid_centers"],
				self.get_grid_levels())

		return cell_centers

	def get_grid_levels(self):
		r"""
		Returns
		-------

		g_levels : ``array``
			the grid levels array

		"""
		return tree_utils.grid_levels(self.amr_struct)


	def sample_points(self, points, add_level=False):
		r"""
		AMR grid point sampling method

		Parameters
		----------
		points : ``array``
			sampling points coordinates array
		add_level : ``boolean`` (default False)
			whether we need to add a `level` field in the returned dataset containing
			the value of the AMR level the sampling points fall into

		Returns
		-------
		dset : ``PointDataset``
			point-based sampled values dataset of the available AMR fields

		"""
		# First find the relevant cells in the tree
		search_dict = tree_utils.tree_search(self.amr_struct, points)

		# Now extract the relevant hydro data
		grids = search_dict["grid_indices"]
		cells = search_dict["cell_indices"]

		# Create an empty PointDataset based on 'points'
		point_dset = PointDataset(points)

		def process(kind_vars, add_func):
			for name in kind_vars:
				data = self[name]
				extracted_data = data[grids, cells]
				add_func(name, extracted_data)

		# Extract the scalars
		process(self.scalars, point_dset.add_scalars)
		# Extract the vectors
		process(self.vectors, point_dset.add_vectors)
		
		# Extract the value of the cell level in which the points are sampled
		if add_level:
			levels = search_dict["levels"]
			point_dset.add_scalars("level", levels)


		return point_dset


	def to_cartesian(self, var, xmin, xmax, level, dest=None):
		return tree_utils.amr2array_3d(self.amr_struct, self[var], self.icpu,
				xmin, xmax, level, dest)


class RamsesOctreeReader(object):

	class Vector(object):
		def __init__(self, name, ivars):
			# Ensure integer ivars
			self.ivars = [int(i) for i in ivars]
			self.name = name

		def gather(self, data, dset):
			vect = numpy.concatenate(
					[numpy.expand_dims(data[ivar], axis=2)
						for ivar in self.ivars], axis=2)
			dset.add_vectors(self.name, vect)


	class Scalar(object):
		def __init__(self, name, ivar):
			self.ivar = int(ivar)
			self.ivars = [self.ivar]
			self.name = name

		def gather(self, data, dset):
			dset.add_scalars(self.name, data[self.ivar])


	fields_by_file = {
		"hydro" : [ Scalar("rho", 0), Vector("vel", [1, 2, 3]), Scalar("P", 4) ],
		"grav"  : [ Vector("g", [0, 1, 2]) ],
		}


	def __init__(self, output_repos, iout, icpu, fields_to_read):

		self.output_repos = output_repos
		self.iout = iout
		self.icpu = icpu
		self.fields_to_read = fields_to_read

		# Transpose the fields_by_file dictionary to allow field -> files
		# mapping
		self.fields_by_name = dict(
			[ ( field_descr.name, (field_file, field_descr) )
				for field_file in self.fields_by_file
					for field_descr in self.fields_by_file[field_file] ])

		self.amr_filename = filename_utils.amrlike_filename(
				"amr", output_repos, iout, icpu, check_exists=True)


	def read(self, read_lmax):
		# Load the AMR structure
		print "Reading amr data  : %s" % self.amr_filename
		amr = read_ramses_amr_file(
				self.amr_filename, max_read_level=read_lmax)
		
		amr_header, amr_struct = amr

		# Construct the octree
		dset = RamsesOctreeDataset(amr)

		# Gather the descriptors of the fields we need to read, grouped by file
		req_descrs_by_file = {}
		for field in self.fields_to_read:
			field_file, field_descr = self.fields_by_name[field]
			if field_file in req_descrs_by_file:
				req_descrs_by_file[field_file].append(field_descr)
			else:
				req_descrs_by_file[field_file] = [field_descr]

		for amr_file_type, descrs in req_descrs_by_file.iteritems():

			# Gather the ivars, uniquify and sort them
			ivars_to_read = []
			for descr in descrs:
				ivars_to_read += descr.ivars
			ivars_to_read = list(set(ivars_to_read))
			ivars_to_read.sort()

			if len(ivars_to_read) == 0:
				continue

			# Output file name
			fname = filename_utils.amrlike_filename(amr_file_type,
					self.output_repos, self.iout, self.icpu,
					check_exists=False)

			# Read the data
			print "Reading %s : %s"%(amr_file_type.ljust(9), fname)
			try:
				data = read_ramses_amr_data_file(fname, amr, ivars_to_read)
			except IOError:
				print "Reading %s failed, associated fields dropped" % fname
				continue

			# Pack the fields into the octree thanks to the descriptors
			for desc in descrs:
				desc.gather(data, dset)

						

		# CPU id in 0-starting indexing
		dset.icpu = self.icpu - 1
		return dset

__all__ = ["RamsesOctreeDataset"]
