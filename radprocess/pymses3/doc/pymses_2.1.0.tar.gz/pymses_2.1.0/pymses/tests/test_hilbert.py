# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
"""
test_hilbert.py -- test module for Hilbert space-filling curve
"""

import pymses.sources.ramses.hilbert as hilbert
import numpy
import os

PWD = os.path.dirname(__file__)

def test_hilbert3d():

	# keys of randomly generated cells as computed by the RAMSES hilbert3d
	# routine
	levels = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
	points = [[   1,    1,    1],
	          [   2,    2,    2],
	          [   5,    4,    3],
	          [   7,    8,    5],
	          [   9,    5,    2],
	          [  28,   14,   41],
	          [  34,   94,  115],
	          [  96,  128,  113],
	          [ 390,  358,  199],
	          [ 193,  612,  832],
	          [1314, 1810, 1444]]

	keys = [5L, 46L, 286L, 1848L, 1786L, 39597L, 617183L, 7559591L, 76270683L,
			326598723L, 5623585136L]

	for point, level, key in zip(points, levels, keys):
		parray = numpy.array([point], hilbert.INT_t)
		hkey = hilbert.compute_hilbert_key(parray, level)
		hkey = hkey[0]
		assert hkey == key


def test_map_box_512():

	# Obtained by running amr2cube
	keys_min, keys_max = numpy.loadtxt(
			os.path.join(PWD, "hilbert_keys_test_512.dat"), unpack=True)
	levelmax = 17
	bbox_min = [0.2, 0.3, 0.6]
	bbox_max = [0.23, 0.45, 0.67]
	cpu_list = [92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105,
			106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118,
			119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131,
			132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144,
			145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157,
			158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170,
			171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183,
			184, 185]

	hdcp = hilbert.HilbertDomainDecomp(3, keys_min, keys_max, levelmax)
	pymses_cpu_list = hdcp.map_box((bbox_min, bbox_max))
	assert numpy.all(pymses_cpu_list == numpy.array(cpu_list, 'i')-1)


def test_map_box_32():

	# Obtained by running amr2cube
	keys_min, keys_max = numpy.loadtxt(
			os.path.join(PWD, "hilbert_keys_test_32.dat"), unpack=True)
	levelmax = 13
	bbox_min = 3*[0.45]
	bbox_max = 3*[0.60]
	cpu_list = [1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 14, 15, 16, 17, 18, 19, 21,
			22, 23, 24, 25, 26, 27, 29, 30, 31, 32]

	hdcp = hilbert.HilbertDomainDecomp(3, keys_min, keys_max, levelmax)
	pymses_cpu_list = hdcp.map_box((bbox_min, bbox_max))
	assert numpy.all(pymses_cpu_list == numpy.array(cpu_list, 'i')-1)
