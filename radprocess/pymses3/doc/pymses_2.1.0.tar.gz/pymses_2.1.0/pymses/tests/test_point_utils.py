# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
import pymses.utils.point_utils as point_utils
import numpy


def test_meshgrid_2d():

	nx, ny = 10, 20
	xgrid, ygrid = numpy.mgrid[0:nx, 0:ny]
	pgrid = numpy.concatenate([xgrid, ygrid])
	plist = pgrid.reshape((2, -1)).transpose()

	xpts = numpy.arange(nx)
	ypts = numpy.arange(ny)
	grid = point_utils.meshgrid([xpts, ypts])

	assert numpy.all(grid == plist)


def test_meshgrid_3d():

	nx, ny, nz = 20, 30, 50
	xgrid, ygrid, zgrid = numpy.mgrid[0:nx, 0:ny, 0:nz]
	pgrid = numpy.concatenate([xgrid, ygrid, zgrid])
	plist = pgrid.reshape((3, -1)).transpose()

	xpts = numpy.arange(nx)
	ypts = numpy.arange(ny)
	zpts = numpy.arange(nz)
	grid = point_utils.meshgrid([xpts, ypts, zpts])

	assert numpy.all(grid == plist)


def test_meshgrid_4d():

	nx, ny, nz, nw = 20, 30, 50, 17
	xgrid, ygrid, zgrid, wgrid = numpy.mgrid[0:nx, 0:ny, 0:nz, 0:nw]
	pgrid = numpy.concatenate([xgrid, ygrid, zgrid, wgrid])
	plist = pgrid.reshape((4, -1)).transpose()

	xpts = numpy.arange(nx)
	ypts = numpy.arange(ny)
	zpts = numpy.arange(nz)
	wpts = numpy.arange(nw)
	grid = point_utils.meshgrid([xpts, ypts, zpts, wpts])

	assert numpy.all(grid == plist)


def test_meshgrid_indexing():
	nx, ny, nz = 20, 30, 50
	xpts = numpy.arange(nx)
	ypts = numpy.arange(ny)
	zpts = numpy.arange(nz)
	grid = point_utils.meshgrid([xpts, ypts, zpts])

	assert tuple(
			grid.reshape(nx, ny, nz, 3)[10, 14, 25, :] ) == (10., 14., 25.)

