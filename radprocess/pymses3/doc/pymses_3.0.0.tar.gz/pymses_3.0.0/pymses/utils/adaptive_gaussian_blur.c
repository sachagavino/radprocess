/******************************************************************************************
* License:                                                                                *
*   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved. *
*                                                                                         *
*   This file is part of PyMSES.                                                          *
*                                                                                         *
*   PyMSES is free software: you can redistribute it and/or modify                        *
*   it under the terms of the GNU General Public License as published by                  *
*   the Free Software Foundation, either version 3 of the License, or                     *
*   (at your option) any later version.                                                   *
*                                                                                         *
*   PyMSES is distributed in the hope that it will be useful,                             *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of                        *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                         *
*   GNU General Public License for more details.                                          *
*                                                                                         *
*   You should have received a copy of the GNU General Public License                     *
*   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.                       *
******************************************************************************************/
//include <stdio.h>
//include <math.h>
//include "adaptive_gaussian_blur.h"

static void compute_same_value_pixel_size_map_C(int * result_map, double * map, int map_max_size_i, int map_max_size_j){
	double val, map_min, map_max, max_val_diff, equal_test_precision;
	printf("Computing same value pixel size map...\n");
	int map_size = map_max_size_i * map_max_size_j;
	int index, map_max_size_j_by_eight, set_size_limit;
	set_size_limit = 10000;
	char test;
	int min_i, max_i, min_j, max_j, max_diff_between_pixel_coordinates, val_i, val_j;
	int same_pixel_value_set_size, new_same_pixel_value_set_size, values_too_add_in_set_number;	
	int i, j, k, l, m, ii, jj;
	char not_all_already_done;
	char * same_value_neighbor_pixel = NULL;
	int * pointer_buffer = NULL;
	same_value_neighbor_pixel = malloc(map_size * 8 * sizeof(char));
	// init to False 
	for (i = 0 ; i < map_size * 8 ; i++)
		same_value_neighbor_pixel[i] = 0;
	// find map min and max:
	map_min = map[0];
	map_max = map[0];
	for (i = 0 ; i < map_size ; i++){
		if (map[i] > map_max)
			map_max = map[i];
		if (map[i] < map_min)
			map_min = map[i];
	}
	max_val_diff = map_max - map_min;
	equal_test_precision = 0.000001 * max_val_diff;
	//printf("max_val_diff = %f\n", max_val_diff );
	// same_value_neighbor_pixel = 3D array [map_i, map_j, 8_neighbor_pixel_index]
	// in this array neighbor pixel x index from 0 to 8 looks like that:
	// 0  1  2    tested in that order :  test_a test_b test_c
	// 3  x  4                            test_d   x      x
	// 5  6  7                              x      x      x
	//printf("compute same_value_neighbor_pixel start\n");
	map_max_size_j_by_eight = map_max_size_j * 8;
	// First loop on map value : compute same_value_neighbor_pixel map
	for (i = 0 ; i < map_max_size_i ; i++){
		for (j = 0 ; j < map_max_size_j ; j++){
			val = map[i * map_max_size_j + j];
			if (i > 0){
				if (j > 0){
					test = fabs(map[(i-1) * map_max_size_j + j-1] - val)<=equal_test_precision;
					//printf("test with == %i\n", (map[(i-1) * map_max_size_j + j-1]) == val );
					//printf("test with <= %i\n", test );
					//if (test){
					//	printf("diff : %10.10f\n", map[(i-1) * map_max_size_j + j-1] - val);
					//	printf("fabs(diff) : %10.10f\n", fabs(map[(i-1) * map_max_size_j + j-1] - val));
					//	printf("test with == 0 : %i\n", (map[(i-1) * map_max_size_j + j-1]) - val == 0 );
					//	printf("test with == val : %i\n", map[(i-1) * map_max_size_j + j-1] == val);
					//	printf("test : %i\n", test);
					//	}
					same_value_neighbor_pixel[i * map_max_size_j_by_eight + j * 8 + 0] = test;
					same_value_neighbor_pixel[(i-1) * map_max_size_j_by_eight + (j-1) * 8 + 7] = test;
				}
				test = fabs(map[(i-1) * map_max_size_j + j] - val)<=equal_test_precision;
				same_value_neighbor_pixel[i * map_max_size_j_by_eight + j * 8 + 1] = test;
				same_value_neighbor_pixel[(i-1) * map_max_size_j_by_eight + j * 8 + 6] = test;
				if (j+1 < map_max_size_j){
					test = fabs(map[(i-1) * map_max_size_j + j+1] - val)<=equal_test_precision;
					same_value_neighbor_pixel[i * map_max_size_j_by_eight + j * 8 + 2] = test;
					same_value_neighbor_pixel[(i-1) * map_max_size_j_by_eight + (j+1) * 8 + 5] = test;
				}
			}
			if (j > 0){
				test = fabs(map[i * map_max_size_j + j-1] - val)<=equal_test_precision;
				same_value_neighbor_pixel[i * map_max_size_j_by_eight + j * 8 + 3] = test;
				same_value_neighbor_pixel[i * map_max_size_j_by_eight + (j-1) * 8 + 4] = test;
			}
		}
	}
	//for (i = 0 ; i < 10 ; i++){
	//	for (j = 0 ; j < 10 ; j++){
	//		printf("\n same_value_neighbor_pixel[%i ",i);
	//		printf(", %i ] = ",j);
	//		printf("%i, ",same_value_neighbor_pixel[i * map_max_size_j_by_eight + j * 8 + 0]);
	//		printf("%i, ",same_value_neighbor_pixel[i * map_max_size_j_by_eight + j * 8 + 1]);
	//		printf("%i, ",same_value_neighbor_pixel[i * map_max_size_j_by_eight + j * 8 + 2]);
	//		printf("%i, ",same_value_neighbor_pixel[i * map_max_size_j_by_eight + j * 8 + 3]);
	//		printf("%i, ",same_value_neighbor_pixel[i * map_max_size_j_by_eight + j * 8 + 4]);
	//		printf("%i, ",same_value_neighbor_pixel[i * map_max_size_j_by_eight + j * 8 + 5]);
	//		printf("%i, ",same_value_neighbor_pixel[i * map_max_size_j_by_eight + j * 8 + 6]);
	//		printf("%i, ",same_value_neighbor_pixel[i * map_max_size_j_by_eight + j * 8 + 7]);
	//
	//	}
	//}
	//printf("compute pixel_size_map start\n");
	char * already_done_map = malloc(map_size * sizeof(char));
	for (k = 0 ; k < map_size ; k++)
		already_done_map[k] = 0;
	int * same_pixel_value_set = malloc(map_size * 2 * sizeof(int));
	int * new_same_pixel_value_set = malloc(map_size * 2 * sizeof(int));
	int * values_too_add_in_set = malloc(16 * sizeof(int));
	int * values_already_in_set = malloc(8 * sizeof(int));
	// Second loop on map value : compute pixel_size_map
	for (i = 0 ; i < map_max_size_i ; i++){
		for (j = 0 ; j < map_max_size_j ; j++){
			if (already_done_map[i*map_max_size_j + j] == 0){
				// consider same_pixel_value_set_size as a new set :
				same_pixel_value_set_size = 1;
				same_pixel_value_set[0] = i;
				same_pixel_value_set[1] = j;
				not_all_already_done = 1;
				if (same_pixel_value_set_size > set_size_limit)
					printf("crack : same_pixel_value_set_size > set_size_limit \n");
				while(not_all_already_done && same_pixel_value_set_size < set_size_limit){
					// copy same_pixel_value_set in new_same_pixel_value_set
					new_same_pixel_value_set_size = same_pixel_value_set_size;
					for (k = 0 ; k < 2*same_pixel_value_set_size ; k++)
						new_same_pixel_value_set[k] = same_pixel_value_set[k];
					for (k = 0 ; k < same_pixel_value_set_size ; k++) {
						ii = same_pixel_value_set[2*k];
						jj = same_pixel_value_set[2*k+1];
						//if (i == 0 && (j == 0 || j == 1)){
						//	printf("\n ii = %i ",ii);
						//	printf(", jj = %i ",jj);
						//}
						if (already_done_map[ii*map_max_size_j + jj] == 0){
							// not already done pixel :
							index = ii*map_max_size_j_by_eight + jj*8;
							values_too_add_in_set_number = 0;
							//if (i == 0 && (j == 0 || j == 1)){
							//	printf("\n index = %i ",index);
							//	printf("\n same_value_neighbor_pixel = %i ",same_value_neighbor_pixel[index + 0]);
							//	printf(", %i",same_value_neighbor_pixel[index + 1]);
							//	printf(", %i",same_value_neighbor_pixel[index + 2]);
							//	printf(", %i",same_value_neighbor_pixel[index + 3]);
							//	printf(", %i",same_value_neighbor_pixel[index + 4]);
							//	printf(", %i",same_value_neighbor_pixel[index + 5]);
							//	printf(", %i",same_value_neighbor_pixel[index + 6]);
							//	printf(", %i",same_value_neighbor_pixel[index + 7]);
							//}
							if (same_value_neighbor_pixel[index + 0]){
								values_too_add_in_set[0] = ii-1;
								values_too_add_in_set[1] = jj-1;
								values_too_add_in_set_number++;
							}
							if (same_value_neighbor_pixel[index + 1]){
								values_too_add_in_set[2*values_too_add_in_set_number] = ii-1;
								values_too_add_in_set[2*values_too_add_in_set_number+1] = jj;
								values_too_add_in_set_number++;
							}
							if (same_value_neighbor_pixel[index + 2]){
								values_too_add_in_set[2*values_too_add_in_set_number] = ii-1;
								values_too_add_in_set[2*values_too_add_in_set_number+1] = jj+1;
								values_too_add_in_set_number++;
							}
							if (same_value_neighbor_pixel[index + 3]){
								values_too_add_in_set[2*values_too_add_in_set_number] = ii;
								values_too_add_in_set[2*values_too_add_in_set_number+1] = jj-1;
								values_too_add_in_set_number++;
							}
							if (same_value_neighbor_pixel[index + 4]){
								values_too_add_in_set[2*values_too_add_in_set_number] = ii;
								values_too_add_in_set[2*values_too_add_in_set_number+1] = jj+1;
								values_too_add_in_set_number++;
							}
							if (same_value_neighbor_pixel[index + 5]){
								values_too_add_in_set[2*values_too_add_in_set_number] = ii+1;
								values_too_add_in_set[2*values_too_add_in_set_number+1] = jj-1;
								values_too_add_in_set_number++;
							}
							if (same_value_neighbor_pixel[index + 6]){
								values_too_add_in_set[2*values_too_add_in_set_number] = ii+1;
								values_too_add_in_set[2*values_too_add_in_set_number+1] = jj;
								values_too_add_in_set_number++;
							}
							if (same_value_neighbor_pixel[index + 7]){
								values_too_add_in_set[2*values_too_add_in_set_number] = ii+1;
								values_too_add_in_set[2*values_too_add_in_set_number+1] = jj+1;
								values_too_add_in_set_number++;
							}
							// add values in set :
							//if (i == 0 && j == 2){
							//	printf("values_too_add_in_set_number :%i \n ",values_too_add_in_set_number);
							//	printf("new_same_pixel_value_set_size :%i \n ",new_same_pixel_value_set_size);
							//}
							if (values_too_add_in_set_number !=0){
								// init values_already_in_set to False
								for (m = 0 ; m < values_too_add_in_set_number; m++){
									values_already_in_set[m] = 0;
								}
								for (l = 0 ; l < new_same_pixel_value_set_size; l++){
									val_i = new_same_pixel_value_set[2*l];
									val_j = new_same_pixel_value_set[2*l+1];
									for (m = 0 ; m < values_too_add_in_set_number; m++){
										if (val_i == values_too_add_in_set[2*m] && val_j == values_too_add_in_set[2*m+1])
											values_already_in_set[m] = 1;
									}
								}
								for (m = 0 ; m < values_too_add_in_set_number; m++){
									if (values_already_in_set[m] == 0){
										// we add the value in the new set :
										//if (i == 0 && (j == 0 || j == 1)){
										//	printf("\n values_too_add_in_set =[%i ",values_too_add_in_set[2*m]);
										//	printf(", %i ] ",values_too_add_in_set[2*m+1]);
										//}
										new_same_pixel_value_set[2*new_same_pixel_value_set_size] = values_too_add_in_set[2*m];
										new_same_pixel_value_set[2*new_same_pixel_value_set_size+1] = values_too_add_in_set[2*m+1];
										new_same_pixel_value_set_size++;
									}
								}
							}
							// this pixel is now done:
							already_done_map[ii*map_max_size_j + jj] = 1;
						}
					}
					not_all_already_done = 0;
					for (k = 0 ; k < new_same_pixel_value_set_size ; k++){
						ii = new_same_pixel_value_set[2*k];
						jj = new_same_pixel_value_set[2*k+1];
						if (already_done_map[ii*map_max_size_j + jj] == 0)
							not_all_already_done = 1;
					}
					// switch old and new set pointer, one will be reused as a new set in next iteration:
					pointer_buffer = same_pixel_value_set;
					same_pixel_value_set = new_same_pixel_value_set;
					same_pixel_value_set_size = new_same_pixel_value_set_size;
					new_same_pixel_value_set = pointer_buffer;
				}
				// find max diff between pixel coordinates in set:
				min_i = map_max_size_i;
				min_j = map_max_size_j;
				max_i = 0;
				max_j = 0;
				//printf("\n same_pixel_value_set_size[%i ",i);
				//printf(", %i ] = ",j);
				//printf("%i, ",same_pixel_value_set_size);
				for (k = 0 ; k < same_pixel_value_set_size ; k++){
					ii = same_pixel_value_set[2*k];
					jj = same_pixel_value_set[2*k+1];
					if (ii < min_i)
						min_i = ii;
					if (jj < min_j)
						min_j = jj;
					if (ii > max_i)
						max_i = ii;
					if (jj > max_j)
						max_j = jj;
				}
				if (max_i - min_i > max_j - min_j)
					max_diff_between_pixel_coordinates = max_i - min_i;
				else
					max_diff_between_pixel_coordinates = max_j - min_j;
				for (k = 0 ; k < same_pixel_value_set_size ; k++)
					result_map[same_pixel_value_set[2*k]*map_max_size_j + same_pixel_value_set[2*k+1]] = max_diff_between_pixel_coordinates;
			}
		}
	}

	// Last loop on map value : extend gauss filter size area by one pixel to reduce the difference where there is a change of pixel size
	int * save_result_map = malloc(map_size * sizeof(int));
	for (k = 0 ; k < map_size ; k++)
		save_result_map[k] = result_map[k];
	char higher_value_neighbor;
	for (i = 0 ; i < map_max_size_i ; i++){
		for (j = 0 ; j < map_max_size_j ; j++){
			val_i = save_result_map[i*map_max_size_j + j];
			// this following code does :
			// if one neighbor pixel in save_result_map is higher
			// then we add 1
			higher_value_neighbor = 0;
			if (i > 0){
				if (j >0 && save_result_map[(i-1)*map_max_size_j + j-1] > val_i)
					higher_value_neighbor = 1;
				if (save_result_map[(i-1)*map_max_size_j + j] > val_i)
					higher_value_neighbor = 1;
				if (j+1 < map_max_size_j && save_result_map[(i-1)*map_max_size_j + j+1] > val_i)
					higher_value_neighbor = 1;
			}
			if (j >0 && save_result_map[i*map_max_size_j + j-1] > val_i)
				higher_value_neighbor = 1;
			if (j+1 < map_max_size_j && save_result_map[i*map_max_size_j + j+1] > val_i)
				higher_value_neighbor = 1;
			if (i+1 < map_max_size_i){
				if (j >0 && save_result_map[(i+1)*map_max_size_j + j-1] > val_i)
					higher_value_neighbor = 1;
				if (save_result_map[(i+1)*map_max_size_j + j] > val_i)
					higher_value_neighbor = 1;
				if (j+1 < map_max_size_j && save_result_map[(i+1)*map_max_size_j + j+1] > val_i)
					higher_value_neighbor = 1;
			}
			if (higher_value_neighbor)
				result_map[i*map_max_size_j + j] += 1;
		}
	}
	
	free(same_value_neighbor_pixel);
	free(already_done_map);
	free(same_pixel_value_set);
	free(new_same_pixel_value_set);
	free(values_too_add_in_set);
	free(values_already_in_set);
	free(save_result_map);
}

static void adaptive_gaussian_blur_C(double * map_filtered, double * original_map, int * same_value_pixel_size_map, int map_max_size_i, int map_max_size_j){
	double distance_to_mask_center_square, gaus_val, mask_val, norm_sum;
	printf("Computing adaptive gaussian blur...\n");
	int max_size = 0;
	int mask_size, size, two_sigma_square, max_mask_size_array, index, mask_size_index;
	int different_size_number = 0;
	int i, j, k, ii, jj;
	char new_value;
	//for (j =0;j<16;j++){
	//	printf(" %i ",j);
	//	printf("same_value_pixel_size_map = %i \n",same_value_pixel_size_map[j]);
	//	printf("map_filtered = %f \n",map_filtered[j]);
	//	printf("original_map = %f \n",original_map[j]);
	//}
	int * different_size = malloc(map_max_size_i * sizeof(int));
	// create mask dict : find every different size mask needed 
	for (i = 0 ; i < map_max_size_i ; i++){
		for (j = 0 ; j < map_max_size_j ; j++){
			size = same_value_pixel_size_map[i * map_max_size_j + j];
			// try to see if it is a new size value
			if (size > 0) {
				new_value = 1;
				for (k = 0 ; k < different_size_number ; k++){
					if (size == different_size[k])
						new_value = 0;
				}
				if (new_value) {
					different_size[different_size_number] = size;
					different_size_number++;
					if (size > max_size)
						max_size = size;
				}
			}
		}
	}
	
	mask_size = max_size + 1;
	max_mask_size_array = mask_size * mask_size;
	double* mask_size_array = malloc(different_size_number * max_mask_size_array * sizeof(double));
	// create mask dict : compute gaussian values for every different size mask 
	for (k = 0 ; k < different_size_number ; k++){
		size = different_size[k];
		mask_size = size + 1;
		norm_sum = 0;
		// we try here with sigma = size but it is probably too big :
		// what about double all mask size and reduce sigma by 2?
		two_sigma_square = 2 * size*size;
		// Use symmetry to reduce thoose loops size by 4 here
		for (i = 0 ; i < mask_size ; i++){
			for (j = 0 ; j < mask_size ; j++){
				distance_to_mask_center_square = (double)(i*i + j*j);
				gaus_val = exp((double)(-distance_to_mask_center_square/two_sigma_square));
				mask_size_array[k * max_mask_size_array + i * mask_size + j] = gaus_val;
				if (i == 0){
					if (j == 0)
						norm_sum += gaus_val;
					else
						norm_sum += 2 * gaus_val;
				}
				else{
					if (j == 0)
						norm_sum += 2 * gaus_val;
					else
						norm_sum += 4 * gaus_val;
				}
			}
		}
		// Norm:
		for (i = 0 ; i < mask_size * mask_size ; i++){
			mask_size_array[k * max_mask_size_array + i] /= norm_sum;
			//if (size == 1){
			//	printf("\n mask_size_array[k * max_mask_size_array + i] : %f",mask_size_array[k * max_mask_size_array + i]);
			//}
		}
	}
	//printf(" different_size_number : %i ",different_size_number);
	// we compute the resulting map
	for (i = 0 ; i < map_max_size_i ; i++){
		for (j = 0 ; j < map_max_size_j ; j++){
			index = i * map_max_size_j + j;
			size = same_value_pixel_size_map[index];
			//if (i == 3 && j == 2){
			//	printf("\noriginal_map[index] : %f",original_map[index]);
			//	printf(" size : %i",size);
			//}
			if (size == 0)
				map_filtered[index] += original_map[index];
			else {
				// find mask size index :
				for (k = 0 ; k < different_size_number ; k++){
					// we should always find a value as it is previously computed
					if (different_size[k] == size)
						mask_size_index = k;
				}
				// eventually compute the gaussian filtered pixel value:
				// Like in mask computation, use symmetry to reduce thoose loops size by 4 here
				// middle mask value :
				map_filtered[index] += original_map[index] * mask_size_array[mask_size_index * max_mask_size_array];
				//if (i == 3 && j == 2){
				//	printf("\nmask_mid : %f ",mask_size_array[mask_size_index * max_mask_size_array]);
				//	printf(" * %f \n",original_map[index]);
				//}
				mask_size = size + 1;
				for (ii = 1 ; ii < mask_size ; ii++){
					// middle cross mask values :
					mask_val = mask_size_array[mask_size_index * max_mask_size_array + ii];
					//if (i == 3 && j == 2){
					//	printf("\nmask_mid : %f ",mask_val);
					//	printf(" * %f \n",original_map[(i-ii) * map_max_size_j + j]);
					//	printf(" * %f \n",original_map[(i+ii) * map_max_size_j + j]);
					//	printf(" * %f \n",original_map[i * map_max_size_j + j-ii]);
					//	printf(" * %f \n",original_map[i * map_max_size_j + j+ii]);
					//}
					if ((i-ii) >= 0)
						map_filtered[index] += original_map[(i-ii) * map_max_size_j + j] * mask_val;
					else
						map_filtered[index] += original_map[j] * mask_val;
					if ((i+ii) < map_max_size_i)
						map_filtered[index] += original_map[(i+ii) * map_max_size_j + j] * mask_val;
					else
						map_filtered[index] += original_map[(map_max_size_i - 1) * map_max_size_j + j] * mask_val;
					if ((j-ii) >= 0)
						map_filtered[index] += original_map[i * map_max_size_j + j - ii] * mask_val;
					else
						map_filtered[index] += original_map[i * map_max_size_j] * mask_val;
					if ((j+ii) < map_max_size_j)
						map_filtered[index] += original_map[i * map_max_size_j + j + ii] * mask_val;
					else
						map_filtered[index] += original_map[i * map_max_size_j + map_max_size_j - 1] * mask_val;
					// others values :
					for (jj = 1 ; jj < mask_size ; jj++){
						mask_val = mask_size_array[mask_size_index * max_mask_size_array + ii * mask_size + jj];
						//if (i == 3 && j == 2){
						//	printf("\nmask_val : %f ",mask_val);
						//	printf(" * %f \n",original_map[(i-ii) * map_max_size_j + j-jj]);
						//	printf(" * %f \n",original_map[(i-ii) * map_max_size_j + j+jj]);
						//	printf(" * %f \n",original_map[(i+ii) * map_max_size_j + j-jj]);
						//	printf(" * %f \n",original_map[(i+ii) * map_max_size_j + j+jj]);
						//}
						if ((i-ii) >= 0) {
							if ((j-jj) >= 0)
								map_filtered[index] += original_map[(i-ii) * map_max_size_j + j-jj] * mask_val;
							else
								map_filtered[index] += original_map[(i-ii) * map_max_size_j] * mask_val;
							if ((j+jj) < map_max_size_j)
								map_filtered[index] += original_map[(i-ii) * map_max_size_j + j+jj] * mask_val;
							else
								map_filtered[index] += original_map[(i-ii) * map_max_size_j + map_max_size_j - 1] * mask_val;
						}
						else {
							if ((j-jj) >= 0)
								map_filtered[index] += original_map[j-jj] * mask_val;
							else
								map_filtered[index] += original_map[0] * mask_val;
							if ((j+jj) < map_max_size_j)
								map_filtered[index] += original_map[j+jj] * mask_val;
							else
								map_filtered[index] += original_map[map_max_size_j - 1] * mask_val;
						}
						if ((i+ii) < map_max_size_i) {
							if ((j-jj) >= 0)
								map_filtered[index] += original_map[(i+ii) * map_max_size_j + j-jj] * mask_val;
							else
								map_filtered[index] += original_map[(i+ii) * map_max_size_j] * mask_val;
							if ((j+jj) < map_max_size_j)
								map_filtered[index] += original_map[(i+ii) * map_max_size_j + j+jj] * mask_val;
							else
								map_filtered[index] += original_map[(i+ii) * map_max_size_j + map_max_size_j - 1] * mask_val;
						}
						else {
							if ((j-jj) >= 0)
								map_filtered[index] += original_map[(map_max_size_i - 1) * map_max_size_j + j-jj] * mask_val;
							else
								map_filtered[index] += original_map[(map_max_size_i - 1) * map_max_size_j] * mask_val;
							if ((j+jj) < map_max_size_j)
								map_filtered[index] += original_map[(map_max_size_i - 1) * map_max_size_j + j+jj] * mask_val;
							else
								map_filtered[index] += original_map[(map_max_size_i - 1) * map_max_size_j + map_max_size_j - 1] * mask_val;
						}
					}
				}
			}
		}
	}
	free(mask_size_array);
	free(different_size);
}

	
	
	
	
	
	
	
	
	
	
	