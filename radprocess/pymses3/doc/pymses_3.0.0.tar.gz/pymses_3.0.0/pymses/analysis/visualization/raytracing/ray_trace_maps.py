# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
import numpy
from pymses.filters import *
from ray_trace import ray_trace_amr, ray_trace_octree
from ..fft_projection.cmp_maps import MapProcessor
from ....sources.ramses.octree import CameraOctreeDatasource, CameraOctreeDataset
from time import time

class RayTracer(MapProcessor):#{{{
	r"""
	RayTracer class

	Parameters
	----------
	ramses_output   : :class:`~pymses.sources.ramses.output.RamsesOutput`
		ramses output from which data will be read to compute the map
	field_list      : ``list`` of ``string``
		list of all the required AMR fields to read (see :meth:`~pymses.sources.ramses.output.RamsesOutput.amr_source`)

	"""
	def __init__(self, ramses_output, field_list):#{{{
		MapProcessor.__init__(self, None)
		self.ro = ramses_output
		self.fields_to_read = field_list
	#}}}

	def process(self, op, camera, surf_qty=False, verbose = False, multiprocessing = True, source = None, use_hilbert_domain_decomp = True):#{{{
		r"""
		Map processing method : ray-tracing through data cube

		Parameters
		----------
		op              : :class:`~pymses.analysis.visualization.Operator`
			physical scalar quantity data operator
		camera          : :class:`~pymses.analysis.visualization.Camera`
			camera containing all the view params
		surf_qty        : ``boolean``
			whether the processed map is a surface physical quantity. If True, the map is divided by the surface of a camera pixel.
		multiprocessing : ``boolean``
			try to use multiprocessing (process cpu data file in parallel) to speed up the code (need more RAM memory, python 2.6 or higher needed)
		
		"""
		begin_time = time()
		# AMR DataSource preparation
		rlev = camera.get_required_resolution()
		#self.ro.verbose = verbose
		if not verbose:
			print self.ro.output_repos, "output", self.ro.iout
		if source == None:
			source = self.ro.amr_source(self.fields_to_read)
			source.set_read_lmax(rlev)

		# Get rays info
		ray_vectors, ray_origins, ray_lengths = camera.get_rays()
		n_rays = ray_origins.shape[0]
		nx_map, ny_map = camera.get_map_size()

		# Data bounding box
		domain_bounding_box = camera.get_bounding_box()

		# Extended domain bounding box
		ext = numpy.sqrt(3.0) * 0.5**(self.ro.info["levelmin"]+1)
		domain_bounding_box.min_coords = numpy.amax([domain_bounding_box.min_coords - ext,[0.,0.,0.]], axis=0)
		domain_bounding_box.max_coords = numpy.amin([domain_bounding_box.max_coords + ext,[1.,1.,1.]], axis=0)
	
		# Data spatial filtering
		rsource = RegionFilter(domain_bounding_box, source)
		print "cpu file to open:",len(rsource._data_list)

		# Maps initialisation
		maps = numpy.zeros((n_rays, op.nscal_func()), dtype='d')
		ray_length_maps = numpy.zeros((n_rays, op.nscal_func()), dtype='d')
		
		# Try to use multiprocessing
		if multiprocessing:
			try:
				from multiprocessing import Process, Queue, cpu_count
				if cpu_count() == 1 :
					multiprocessing = False # don't use multiprocessing if there is only one cpu
			except Exception:
				print 'WARNING: multiprocessing unavailable'
				multiprocessing = False
		if multiprocessing:
			###########################################
			# multiprocessing on cpu file ray tracing #
			###########################################
			# CPU files to read
			cpu_full_list = rsource._data_list
			ncpufile = len(cpu_full_list)
			
			# Create one cpu_list for each node:
			t0 = time()
			ray_time = 0
			from pymses.utils import misc
			NUMBER_OF_PROCESSES = min(len(cpu_full_list), cpu_count(), misc.NUMBER_OF_PROCESSES_LIMIT)
			
			
			def process_dset(rsource, ray_origins, ray_vectors, ray_lengths, op, ro_info,\
					 cpu_task_queue, maps_queue, ray_length_maps_queue):
				"""Utility method for the Source.flatten() multiprocessing method. 
				It reads the source files and concatenate resulting dsets
				Parameters
				----------
				source : `Source`
					data source
				"""
				if verbose: print "process with cpu_list",rsource._data_list,"started!"
				maps = numpy.zeros((nx_map * ny_map, op.nscal_func()), dtype='d')
				mapsDset = numpy.zeros((nx_map * ny_map, op.nscal_func()), dtype='d')
				ray_length_maps = numpy.zeros((nx_map * ny_map, op.nscal_func()), dtype='d')
				if verbose: print "process with cpuList",rsource._data_list," begin iter dsets!"
				for icpu in iter(cpu_task_queue.get, 'STOP'):
					dset = rsource.get_domain_dset(icpu)
					active_mask = dset.get_active_mask()
					g_levels =  dset.get_grid_levels()
					# We do the processing only if needed, i.e. only if the amr level min
					# of active cells in the dset is <= rlev
					if len(g_levels[active_mask]) > 0 and numpy.min(g_levels[active_mask]) <= rlev:
						mapsDset,ray_length_mapsDset = ray_trace_amr(dset, ray_origins, ray_vectors, \
							ray_lengths, op, self.ro.info, rlev, active_mask, g_levels, use_C_code = True,\
							use_hilbert_domain_decomp=use_hilbert_domain_decomp)
						ray_length_maps += ray_length_mapsDset
						if op.is_max_alos():
							maps = numpy.max(numpy.array([maps, mapsDset]), axis=0)
						else:
							maps += mapsDset
						if verbose: print "computation for icpu", icpu, "has been done!"
				maps_queue.put(maps)
				ray_length_maps_queue.put(ray_length_maps)
			# Create queues
			cpu_task_queue = Queue()
			maps_queue = Queue()
			ray_length_maps_queue = Queue()
			# Submit tasks
			for task in cpu_full_list:
				cpu_task_queue.put(task)
			# Start worker processes
			for i in range(NUMBER_OF_PROCESSES):
				Process(target=process_dset, args=(rsource, ray_origins, ray_vectors, \
					ray_lengths, op, self.ro.info, cpu_task_queue, maps_queue,\
					ray_length_maps_queue)).start()
			# Tell child processes to stop when they have finished
			for i in range(NUMBER_OF_PROCESSES):
				cpu_task_queue.put('STOP')
			# Get results
			for i in range(NUMBER_OF_PROCESSES):
				if op.is_max_alos():
					maps = numpy.max(numpy.array([maps, maps_queue.get()]), axis=0)
				else:
					maps += maps_queue.get()
				ray_length_maps += ray_length_maps_queue.get()
		else:
			###############################################
			# no multiprocessing : sequential ray tracing #
			###############################################
			for icpu in rsource._data_list:
				dset = rsource.get_domain_dset(icpu)
				active_mask = dset.get_active_mask()
				g_levels =  dset.get_grid_levels()
				# We do the processing only if needed, i.e. only if the amr level min of active cells in the dset is <= rlev
				if len(g_levels[active_mask]) > 0 and numpy.min(g_levels[active_mask]) <= rlev:
					mapsDset,ray_length_mapsDset = ray_trace_amr(dset, ray_origins, ray_vectors, \
						ray_lengths, op, self.ro.info, rlev, active_mask, g_levels, use_C_code = True,\
						use_hilbert_domain_decomp = use_hilbert_domain_decomp)
					ray_length_maps += ray_length_mapsDset
					if op.is_max_alos():
						maps = numpy.max(numpy.array([maps, mapsDset]), axis=0)
					else:
						maps += mapsDset
					
		print "Ray trace process time=", time() - begin_time
		
		different_ray_length = numpy.unique(ray_length_maps)
		equal = True
		if len(different_ray_length) > 1:
			if (numpy.max(different_ray_length) - numpy.min(different_ray_length)) > ray_lengths[0] * 10e-3:
				equal = False
				print "Calculated ray lengths during the ray trace process are not always equal"
				if len(different_ray_length) < 5:
					print "ray_lengths[0] =", ray_lengths[0]
					for value in different_ray_length:
						print "There are", sum(ray_length_maps == value), "ray(s) with value", value
		if equal:
			print "Calculated ray lengths during the ray trace process are all equal : visualized volume is complete ! :-)"
		
		ifunc=0
		map_dict = {}
		S = camera.get_pixel_surface()
		for key, func in op.iter_scalar_func():
			if (op.is_max_alos()+surf_qty):
				map_dict[key] = maps[:,ifunc].reshape(nx_map, ny_map)
			else:
				map_dict[key] = S * maps[:,ifunc].reshape(nx_map, ny_map)
			ifunc+=1
		map = op.operation(map_dict)

		# Return log-scale map if the camera captors are log-sensitive
		if camera.log_sensitive:
			min_map = numpy.min(map[(map > 0.0)])
			numpy.clip(map, min_map, map.max(), out=map)
			map = numpy.log10(map)
		return map
	#}}}

#}}}

class OctreeRayTracer(MapProcessor):#{{{
	r"""
	RayTracerDir class

	Parameters
	----------
	ramses_output   : :class:`~pymses.sources.ramses.output.RamsesOutput`
		ramses output from which data will be read to compute the map
	field_list      : ``list`` of ``string``
		list of all the required AMR fields to read (see :meth:`~pymses.sources.ramses.output.RamsesOutput.amr_source`)

	"""
	def __init__(self, * args):#{{{
		nargs = len(args)
		assert nargs in [1,2]
		if nargs == 1:
			dset = args[0]
			assert isinstance(dset, CameraOctreeDataset)
			MapProcessor.__init__(self, dset)
		else:
			MapProcessor.__init__(self, None)
			self.ro, self.fields_to_read = args
	#}}}

	def process(self, op, camera, surf_qty=False, return_image = True):#{{{
		r"""
		Map processing method : directional ray-tracing through AMR tree

		Parameters
		camera          : :class:`~pymses.analysis.visualization.Camera`
			camera containing all the view params
		
		"""
		begin_time = time()
		if self.source is None:
			# CameraOctreeDatasource creation
			source = self.ro.amr_source(self.fields_to_read)
			# with son indices when the reading is limited to rlev. We also cannot get correct active mask.
			esize = 0.5**(self.ro.info["levelmin"]+1)
			cod = CameraOctreeDatasource(camera, esize, source)
			self.source = cod.dset
		
		# Get rays info
		ray_vectors, ray_origins, ray_lengths = camera.get_rays()
		n_rays = ray_origins.shape[0]
		nx_map, ny_map = camera.get_map_size()

		# Maps initialisation
#		maps = numpy.zeros((n_rays, op.nscal_func()), dtype='d')
		
		I = ray_trace_octree(self.source, ray_origins, ray_vectors, ray_lengths, op, camera.color_tf)
		print "Octree ray trace processing time=", time() - begin_time
		shape = I.shape
		I = I.reshape(shape[0]*shape[1])
		if sum(I!=I) !=0:
			print "Error : There are",sum(I!=I)," NaN value"
		if not return_image :
			return I.reshape((nx_map, ny_map, 3))
		else:
			import Image
			map = I.reshape((nx_map*ny_map, 3))
			#map = (map - min(map)) / (max(map) - min(map))
			map[:,0] = (map[:,0] - min(map[:,0])) / (max(map[:,0]) - min(map[:,0]))
			map[:,1] = (map[:,1] - min(map[:,1])) / (max(map[:,1]) - min(map[:,1]))
			map[:,2] = (map[:,2] - min(map[:,2])) / (max(map[:,2]) - min(map[:,2]))
			map = numpy.asarray(map*255, dtype='i')
			R_band = Image.new("L",(nx_map,ny_map))
			R_band.putdata(map[:,0])
			#import pylab as P
			#P.imshow(map[:,2].reshape((nx_map,ny_map)))
			#P.show()
			G_band = Image.new("L",(nx_map,ny_map))
			G_band.putdata(map[:,1])
			B_band = Image.new("L",(nx_map,ny_map))
			B_band.putdata(map[:,2])
			img = Image.merge("RGB", (R_band, G_band, B_band))
			return img.rotate(90)
	#}}}

#}}}

__all__ = ["RayTracer", "OctreeRayTracer"]
