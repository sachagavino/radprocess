# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
from ramses_sim import RamsesSimController
from los_axes3d import LineOfSightController
from region_finder import RegionFinderController
from map_tabs import MapTabController

from ..model import Model

class Controller(RamsesSimController, LineOfSightController, \
		RegionFinderController, MapTabController):
	def __init__(self, gui):
		self.gui = gui
		RamsesSimController.__init__(self)
		LineOfSightController.__init__(self)
		RegionFinderController.__init__(self)
		MapTabController.__init__(self)
		self.model = Model()

	def SetWidgetsDict(self, widgets):
		self.widgets = widgets

	def OnReset(self, event):
		self.model.reset()
		self.gui.reset()
		
	def SaveLosCameraToHDF5(self, h5fname):
		return self.model.SaveLosCameraToHDF5(h5fname)

	def LoadLosCameraFromHDF5(self, h5fname):
		self.model.reset()
		self.model.LoadLosCameraFromHDF5(h5fname)
		self.gui.reset()
	
	def LoadmapFromHDF5(self, h5fname):
		self.model.LoadmapFromHDF5(h5fname)

	def updateImages(self, wx_event = None, color_change = False, verbose = True):
		if self.active_tab == None:
			if self.model.image_computed.has_key("regionFinder") or not color_change:
				# this test avoid a bug when user try to change the color 
				# while image is not already computed
				self.RegionFinderButtonClick(color_change = color_change, verbose = verbose)
		elif self.model.image_computed.has_key(self.active_tab) or not color_change:
			# this test avoid a bug when user try to change the color 
			# while image is not already computed
			self.TabMapWindowUpdateClick(color_change = color_change, verbose = verbose)

	def SetRegionFinderHelpMessage(self):
		self.gui.statusBar.SetStatusText(" Left click on two axis views to define a zoom box center (right click = cancel)",0)
		self.gui.statusBar.SetStatusText(" Mouse wheel = zoom box size",1)



