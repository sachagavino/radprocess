# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
from camera import Camera
from ..point_sampler import sample_points
import types
import numpy

def SliceMap(source, camera, op, z=0.0):
	"""
	Compute a map made of sampling points

	Parameters
	----------
	source : ``Source``
		data source
	camera : :class:`~pymses.analysis.visualization.Camera`
		camera handling the view parameters
	op     : :class:`~pymses.analysis.visualization.Operator`
		data sampling operator
	z      : ``float``
		position of the slice plane along the line-of-sight axis of the camera

	Returns
	-------
	map : ``array``
		sliced map

	"""
	# Map size
	nx, ny = camera.get_map_size()

	# Sammpling points
	p = camera.get_slice_points(z)

	# Get dataset
	dset = sample_points(source, p)
	
	# Compute map values according to operator
	maps = {}
	for key, func in op:
		maps[key] = func(dset)
	map = op.operation(maps)

	map = map.reshape(nx, ny)
		
	# Return log-scale map if the camera captors are log-sensitive
	if camera.log_sensitive:
		if (map>0.0).any():
			min_map = numpy.min(map[(map > 0.0)])
			numpy.clip(map, min_map, map.max(), out=map)
			map = numpy.log10(map)
	
	return map

__all__ = ["SliceMap"]
