# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
from tempfile import mkstemp
from os import listdir
from os.path import basename, dirname
from pymses.utils import constants as C
from pymses.sources.ramses.output import RamsesOutput
from pymses.sources.ramses.filename_utils import search_valid_outputs
from pymses.utils.regions import Box
from pymses.analysis.visualization import *
from pymses.filters.cell_to_points import *
from pymses.filters.region_filter import *
from utils import get_appropriate_unit
import numpy as N
import tables as T
import re

class RamsesModel:#{{{
	
	tunit_dict = {'yr': C.year, 'Myr': C.Myr, 'Gyr': C.Gyr}

	def __init__(self):
		self.ramses_dir = None
		self.iout_list = None
		self.selected_iout_index = 0
		self.ro = None
		self.cmap = "jet"
	

	def SearchValidOutputs(self, out_dir):#{{{
		"""
		Search for valid RAMSES outputs in the out_dir directory
		Records the ramses_dir and the sorted iout_list if valid outputs are found and return True
		Return False if none is found
		"""
		if out_dir is None:
			if self.ramses_dir is None:
				return False
			else:
				out_dir = self.ramses_dir
		ilist = search_valid_outputs(out_dir)
		ok = (len(ilist) > 0)
		self.selected_iout_index = 0
		if not ok :
			# try to see if up directory is not already a good directory
			out_up_dir = dirname(out_dir)
			ilist = search_valid_outputs(out_up_dir)
			ok = (len(ilist) > 0)
			if ok:
				# Find output number iout
				outName = basename(out_dir)
				iout_regexp = re.compile("[0-9]{5}")
				iout_parse = iout_regexp.findall(outName)
				if len(iout_parse) > 0:
					iout = int(iout_parse[0])
					self.selected_iout_index = ilist.index(iout)
				self.iout_list = ilist
				self.ramses_dir = out_up_dir
		else:
			self.iout_list = ilist
			self.ramses_dir = out_dir
		return ok, self.selected_iout_index
	#}}}

	def GetvalidOutputsList(self):
		return self.iout_list

	def SetRamsesOutput(self, iout_index):#{{{
		"""
		If iout is in self.iout_list :
		- Sets the chosen RamsesOutput according to the iout number
		- Init. the region size (boxlen)
		- Return True

		Return False if not.
		"""
		if not iout_index in range(len(self.iout_list)):
			return False
		self.selected_iout_index = iout_index
		iout = self.iout_list[iout_index]
		self.ro = RamsesOutput(self.ramses_dir, iout)
		self.freeTheMemory()
		self.SetRegionSizeUnit(self.ro.info["unit_length"])
		return True
	#}}}

	def GetOutputTime(self):#{{{
		t = self.ro.info["unit_time"] * self.ro.info["time"]
		return get_appropriate_unit(t, RamsesModel.tunit_dict)
	#}}}

#}}}


class MapEngine(object):#{{{
	def __init__(self, field_list, ramses_output, use_particle_source = False):
		"""
			Turn the multiprocessing option to True to compute the region finder 
			maps in parallel only if there is a lot of memory availale on the machine
		"""
		self.field_list = field_list
		self.ramses_output = ramses_output
		if use_particle_source:
			self.source = self.ramses_output.particle_source(self.field_list)
		else:
			self.source = self.ramses_output.amr_source(self.field_list)
		self.mp = None
			

	def MakeMaps(self, cam_dict, cmap, multiprocessing, FFTkernelSizeFactor, cache_dset):#{{{
		# Map computation
		self.map_h5files={}
		if self.mp == None:
			self.mp = fft_projection.MapFFTProcessor(self.source, self.ramses_output.info, remember_data = True, cache_dset = cache_dset)
		self.mp.prepare_data(cam_dict.values()[0], self.field_list) # prepare data with the first camera
		map_name_list = []
		if multiprocessing:
			try:
				from multiprocessing import Process, Pipe, cpu_count
				if cpu_count() == 1:
					raise(Exception) # don't use multiprocessing if there is only one cpu
				print 'Multiprocessing Activated'
				p={}
				parent_conn={}
				child_conn={}
				def process_cam(self, axis, cam, conn):
					# Map parameters
					mapname = "wx_AMRViewer_%s_%s"%(self.getMapName(),axis)
					fhandle, fname = mkstemp(prefix=mapname, suffix=".h5")
					mname = basename(fname)[:-3]
					tdir = dirname(fname)
					conn.send(fname)

					scal_func = self.getMapOperator(cam)
					mmap = self.mp.process(scal_func, cam, surf_qty=self.IsSurfQuantity(), FFTkernelSizeFactor = FFTkernelSizeFactor, data_already_prepared = True)
					mu = self.getMapUnit()
					au = self.ramses_output.info["unit_length"]
					self.map_h5files[axis] = save_map_HDF5(mmap, cam, unit=mu, scale_unit=au, hdf5_path=tdir, map_name=mname)
					conn.send(self.map_h5files[axis])
					conn.close()

				# Start process
				for axis, cam in cam_dict.iteritems():
					parent, child = Pipe()
					parent_conn[axis] = parent
					child_conn[axis] = child
					p[axis] = Process(target=process_cam, args=(self, axis, cam, child_conn[axis]))
					p[axis].start()
				# End Process
				for axis, cam in cam_dict.iteritems():
					map_name_list.append(parent_conn[axis].recv())
					self.map_h5files[axis] = parent_conn[axis].recv()
					p[axis].join()
			except Exception:
				print 'WARNING: multiprocessing unavailable'
				multiprocessing = False
		if not multiprocessing:
			for axis, cam in cam_dict.iteritems():
				# Map parameters
				mapname = "wx_AMRViewer_%s_%s"%(self.getMapName(),axis)
				fhandle, fname = mkstemp(prefix=mapname, suffix=".h5")
				mname = basename(fname)[:-3]
				tdir = dirname(fname)
				map_name_list.append(fname)

				scal_func = self.getMapOperator(cam)
				mmap = self.mp.process(scal_func, cam, surf_qty=self.IsSurfQuantity(), FFTkernelSizeFactor = FFTkernelSizeFactor, data_already_prepared = True)
				mu = self.getMapUnit()
				au = self.ramses_output.info["unit_length"]
				self.map_h5files[axis] = save_map_HDF5(mmap, cam, unit=mu, scale_unit=au, hdf5_path=tdir, map_name=mname)
		self.mp.free_filtered_source()# Free filtered data
		return map_name_list
	#}}}

	@staticmethod
	def MakeImage(map_name_list_or_img_dict, axis_keys, cmap, adaptive_gaussian_blur, ramses_output=None, verbose = True):
		if isinstance(map_name_list_or_img_dict, list):
			def h5f_iter():
				for map_name in map_name_list_or_img_dict:
					yield map_name
			img_iter = save_HDF5_seq_to_img(h5f_iter, cmap=cmap, adaptive_gaussian_blur = adaptive_gaussian_blur, fraction=0.1, ramses_output=ramses_output, verbose = verbose)
			imglist = [img for img in img_iter()]
			img_dict = dict(zip(axis_keys, imglist))
			return img_dict
		else:
			imglist=[]
			for axis in axis_keys:
				imglist.append(map_name_list_or_img_dict[axis])
			img_dict = dict(zip(axis_keys, imglist))
			return img_dict

	def GetMapArrays(self):#{{{
		"""
		Get the numpy.array of the maps contained in each HDF5 file of
		the self.h5files dict.
		The returned maps are maskred and clipped.
		"""
		ma = {}
		for axis, h5fname in self.map_h5files.iteritems():
			h5f = T.openFile(h5fname, 'r')
			cam = Camera.from_HDF5(h5f)
			map = h5f.getNode("/map/map").read()
			map_mask = h5f.getNode("/map/map_mask").read()
			h5f.close()
			nx, ny = map.shape
#			map = map.transpose()
#			map_mask = map_mask.transpose()
			vmin, vmax = get_map_range(map[(map_mask>0.)], cam.log_sensitive, None, 0.1)
			map = N.clip(map[:,::-1], vmin, vmax)
			if cam.log_sensitive:
				map = 10.**map
			ma[axis] = map
		return ma
	#}}}

	def getMapName(self):
		raise NotImplementedError()
	
	def getUnitDict(self):
		raise NotImplementedError()

	def getMapUnit(self):
		raise NotImplementedError()

	def getMapOperator(self, cam):
		raise NotImplementedError()

	def IsSurfQuantity(self):
		return False

	
#}}}

class RayTraceEngine(MapEngine):#{{{
	def __init__(self, ramses_output):
		fl = ["rho"]
		MapEngine.__init__(self, fl, ramses_output)
		self.rt = raytracing.RayTracer(ramses_output, fl)
	
	def MakeMaps(self, cam_dict, cmap, multiprocessing, FFTkernelSizeFactor, cache_dset):#{{{
		# Map computation
		self.map_h5files={}
		map_name_list = []
		for axis, cam in cam_dict.iteritems():
			# Map parameters
			mapname = "wx_AMRViewer_%s_%s"%(self.getMapName(),axis)
			fhandle, fname = mkstemp(prefix=mapname, suffix=".h5")
			mname = basename(fname)[:-3]
			tdir = dirname(fname)
			map_name_list.append(fname)
			scal_func = self.getMapOperator(cam)
			if scal_func == MaxLevelOperator:
				cam.log_sensitive = False
			mmap = self.rt.process(scal_func, cam, surf_qty=self.IsSurfQuantity())
			mu = self.getMapUnit()
			au = self.ramses_output.info["unit_length"]
			self.map_h5files[axis] = save_map_HDF5(mmap, cam, unit=mu, scale_unit=au, hdf5_path=tdir, map_name=mname)
		return map_name_list
	#}}}

	@classmethod
	def is_map_engine_for(cls, map_type):
		return map_type == "levelmax"
	
	def getMapName(self):
		return "amr_max_ref_level"

	def getMapUnit(self):
		return C.none

	def getUnitDict(self):
		d = {"": C.none}
		return d
			
	def getMapOperator(self, cam):
		op = MaxLevelOperator()
		return op
#}}}

class RayTraceDensityEngine(RayTraceEngine, MapEngine):#{{{
	@classmethod
	def is_map_engine_for(cls, map_type):
		return map_type == "densityRT"
	
	def getMapName(self):
		return "gas_densityRT"

	def getMapUnit(self):
		return self.ramses_output.info["unit_density"]

	def getUnitDict(self):
		d = {"H/cc": C.H_cc}
		return d
			
	def getMapOperator(self, cam):
		num_func = lambda dset: (dset["rho"]**2)
		denom_func = lambda dset: (dset["rho"])
		op = FractionOperator(num_func, denom_func)
		return op

class MassWeightedDensityMapEngine(MapEngine):#{{{
	def __init__(self, ramses_output):
		MapEngine.__init__(self, ["rho"], ramses_output)

	@classmethod
	def is_map_engine_for(cls, map_type):
		return map_type == "density"

	def getMapName(self):
		return "gas_mw_density"

	def getMapUnit(self):
		return self.ramses_output.info["unit_density"]

	def getUnitDict(self):
		d = {"H/cc": C.H_cc}
		return d
			
	def getMapOperator(self, cam):
		num_func = lambda dset: (dset["rho"]**2 * dset.get_sizes()**3)
		denom_func = lambda dset: (dset["rho"] * dset.get_sizes()**3)
		return FractionOperator(num_func, denom_func)
#}}}

class SurfaceDensityMapEngine(MapEngine):#{{{
	def __init__(self, ramses_output):
		MapEngine.__init__(self, ["rho"], ramses_output)
	
	@classmethod
	def is_map_engine_for(cls, map_type):
		return map_type == "Sigma"
	
	def getMapName(self):
		return "gas_Sigma"

	def getUnitDict(self):
		d = {"Msun/pc^2": C.Msun/C.pc**2}
		return d
	
	def getMapUnit(self):
		u = self.ramses_output.info["unit_density"] * \
				self.ramses_output.info["unit_length"]
		return u
			
	def getMapOperator(self, cam):
		f = ScalarOperator(lambda dset: (dset["rho"] * dset.get_sizes()**3))
		return f
	
	def IsSurfQuantity(self):
		return True
#}}}

class MassWeightedTemperatureMapEngine(MapEngine):#{{{
	def __init__(self, ramses_output):
		MapEngine.__init__(self, ["P", "rho"], ramses_output)
	
	@classmethod
	def is_map_engine_for(cls, map_type):
		return map_type == "temperature"
	
	def getMapName(self):
		return "gas_mw_T"
	
	def getUnitDict(self):
		d = {"K": C.K}
		return d

	def getMapUnit(self):
		return self.ramses_output.info["unit_temperature"]
			
	def getMapOperator(self, cam):
		num_func = lambda dset: (dset["P"] * dset.get_sizes()**3)
		denom_func = lambda dset: (dset["rho"] * dset.get_sizes()**3)
		return FractionOperator(num_func, denom_func)
#}}}

# Line-of-sight velocity map engines {{{
class MassWeightedVelocityDispMapEngine(MapEngine):#{{{
	def __init__(self, ramses_output):
		MapEngine.__init__(self, ["vel", "rho"], ramses_output)
	
	@classmethod
	def is_map_engine_for(cls, map_type):
		return map_type == "velocity"

	def MakeMaps(self, cam_dict, cmap,  multiprocessing, FFTkernelSizeFactor, cache_dset):
		for c in cam_dict.values():
			c.log_sensitive = False
		return MapEngine.MakeMaps(self, cam_dict, cmap, multiprocessing, FFTkernelSizeFactor, cache_dset = cache_dset)

	def getMapName(self):
		return "gas_mw_V"
	
	def getUnitDict(self):
		d = {"km/s": C.km/C.s}
		return d
	
	def getMapUnit(self):
		return self.ramses_output.info["unit_velocity"]

	def getMapOperator(self, cam):
		num_func = lambda dset: (-N.sum(cam.los_axis[N.newaxis,:] * dset["vel"], axis=1) *\
				dset["rho"] * dset.get_sizes()**3)
		denom_func = lambda dset: (dset["rho"] * dset.get_sizes()**3)
		return FractionOperator(num_func, denom_func)

#}}}

class ParticleMassMapEngine(MapEngine):#{{{
	def __init__(self, ramses_output):
		MapEngine.__init__(self, ["mass", "level"], ramses_output, use_particle_source = True)
	
	@classmethod
	def is_map_engine_for(cls, map_type):
		return map_type == "particles"
	
	def getMapName(self):
		return "particles_Vlos"
	
	def getUnitDict(self):
		d = {"Msun/pc^2": C.Msun/C.pc**2}
		return d
	
	def getMapUnit(self):
		u = self.ramses_output.info["unit_mass"] / \
				self.ramses_output.info["unit_length"]**2
		return u

	def getMapOperator(self, cam):
		return ScalarOperator(lambda dset: dset["mass"])
#}}}

class TransferRayTraceEngine(MapEngine):#{{{
	def __init__(self, ramses_output):
		self.ramses_output = ramses_output
	
	def MakeMaps(self, cam_dict, cmap, multiprocessing, FFTkernelSizeFactor, cache_dset):#{{{
		# Map computation
		img_dict={}
		self.map_array = {}
		rt = raytracing.OctreeRayTracer(self.ramses_output, ["rho"])
		for axis, cam in cam_dict.iteritems():
			cltf = ColorLinesTransferFunction( (-5.0, 2.0) )
			cltf.add_line(-2.0, 0.1)
			cltf.add_line(.0, 0.1)
			cltf.add_line(2., 0.1)
			cam.set_color_transfer_function(cltf)
			# We add 1e-8 to avoid NaN and -Inf log result problems with approximative null values
			op = ScalarOperator(lambda dset: N.log10(dset["rho"]+1e-8))
			img_dict[axis] = rt.process(op, cam).convert("RGBA")
			self.map_array[axis] =  N.zeros(cam.get_map_size())
		return img_dict
	#}}}
	
	def GetMapArrays(self):#{{{
		return self.map_array

	@classmethod
	def is_map_engine_for(cls, map_type):
		return map_type == "transfer_function"
	
	def getMapName(self):
		return "transfer_function_map"

	def getMapUnit(self):
		return C.none

	def getUnitDict(self):
		d = {"": C.none}
		return d
#}}}

class hdf5ViewerEngine(MapEngine):#{{{
	def __init__(self, ramses_output):
		self.ramses_output = ramses_output
	
	def GetMapArrays(self):#{{{
		return self.map_array

	@classmethod
	def is_map_engine_for(cls, map_type):
		return map_type == "hdf5"
	
	def getMapName(self):
		return "hdf5_map"
#}}}

def map_engine(map_type, ramses_output):#{{{
	for cls in MapEngine.__subclasses__():
		if cls.is_map_engine_for(map_type):
			return cls(ramses_output)
	raise ValueError("No MapEngine available for map type '%s'"%map_type)
#}}}
