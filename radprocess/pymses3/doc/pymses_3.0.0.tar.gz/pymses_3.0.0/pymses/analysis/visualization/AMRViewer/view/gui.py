# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
import wx
from widget_ids import WidgetIds as wid
from about import open_about_box
from left_panel import LeftPanel
from notebook import Notebook
from dialogs import *
from ..ctrl import Controller
from utils import get_icon
import os

class GUI(wx.App):#{{{
	def OnInit(self):
		frame = MainWindow(None, title='AMRViewer')
		self.SetTopWindow(frame)
		return True

	def run(self):
		self.MainLoop()

#}}}

class MainWindow(wx.Frame):#{{{

	def __init__(self, parent, title):#{{{
		"""
		"""
		WID = wid()
		wx.Frame.__init__(self, parent, WID.ANY, title=title)
				
		# Controller
		self.controller = Controller(self)

		# Model
		self.model = self.controller.model


		# Setting up the menubar {{{
		filemenu= wx.Menu()
		menuOpen = filemenu.Append(WID.MENU_OPEN, "&Open RAMSES simulation"," Open a RAMSES outputs directory")
		menuExit = filemenu.Append(WID.MENU_QUIT,"&Quit"," Terminate the AMRViewer")
		
		cameramenu= wx.Menu()
		menuResetCam = cameramenu.Append(WID.TOOL_RESET, "&Reset view"," Reset view")
		menuLoadCam = cameramenu.Append(WID.MENU_LOADCAM, "&Load camera..."," Load a camera from a HDF5 file")
		menuSaveCam = cameramenu.Append(WID.MENU_SAVECAM, "&Save camera into file..."," Save the camera into a HDF5 file")

		tabdisplaymenu= wx.Menu()
		for tab_index in range(len(WID.TAB_NAME_LIST)):
			tab_name = WID.TAB_NAME_LIST[tab_index]
			descr = WID.TAB_DESCR_LIST[tab_name]
			tabdisplaymenu.Append(WID.TAB_MENU_IDS[tab_name], "%s"%descr," Show/hide tab : '%s'"%descr, wx.ITEM_CHECK)
			if tab_name != "hdf5":
				tabdisplaymenu.Check(WID.TAB_MENU_IDS[tab_name], True)
		
		helpmenu= wx.Menu()
		menuAbout= helpmenu.Append(WID.MENU_ABOUT, "&About"," Information on AMRViewer")
		
		menuBar = wx.MenuBar()
		menuBar.Append(filemenu,"&File") # Adding the "filemenu" to the MenuBar
		menuBar.Append(cameramenu,"&Camera") # Adding the "cameramenu" to the MenuBar
		menuBar.Append(tabdisplaymenu,"&Display") # Adding the "tabdisplaymenu" to the MenuBar
		menuBar.Append(helpmenu,"&Help") # Adding the "helpmenu" to the MenuBar
		self.SetMenuBar(menuBar)  # Adding the MenuBar to the Frame content.
		#}}}
		
		# Toolbar creation + events {{{
		sizer = wx.BoxSizer(wx.VERTICAL)
		self.toolbar_sizer = wx.BoxSizer(wx.HORIZONTAL)
		self.toolbar_panel = wx.Panel(self, -1)
		self.toolbar_panel.SetSizer(self.toolbar_sizer)
		self.SetSizer(sizer)
		toolbar = wx.ToolBar(self, -1, style=wx.TB_HORIZONTAL)
		toolbar.AddSimpleTool(WID.TOOL_OPEN, wx.Bitmap(get_icon("open.png")), '', 'Open a RAMSES outputs directory')
		toolbar.AddSeparator()
		toolbar.AddSimpleTool(WID.TOOL_QUIT, wx.Bitmap(get_icon("quit.png")), '', 'Terminate the AMRViewer')
		toolbar.AddSeparator()
		toolbar.AddSimpleTool(WID.TOOL_RESET, wx.Bitmap(get_icon("reset.png")), '', 'Reset view')
		toolbar.AddSimpleTool(WID.MENU_LOADCAM, wx.Bitmap(get_icon("camera_open.png")), '', 'Load a camera from a HDF5 file')
		toolbar.AddSimpleTool(WID.MENU_SAVECAM, wx.Bitmap(get_icon("camera_save.png")), '', 'Save the camera into a HDF5 file')
		toolbar.AddSeparator()
		toolbar.AddSimpleTool(WID.TOOL_SAVE_IMAGE, wx.Bitmap(get_icon("save.png")), '', 'Save image')
		toolbar.AddSimpleTool(WID.TOOL_UPDATE, wx.Bitmap(get_icon("update.png")), '', 'Update map')
		
		toolbar.Realize()
		self.toolbar_sizer.Add(toolbar,wx.ALIGN_LEFT)
		
		self.hdf5_cb = wx.ComboBox(self.toolbar_panel, WID.ANY, size=(400,-1), style=wx.CB_READONLY)
		self.hdf5_cb.SetToolTip(wx.ToolTip("This box is only used to select files in hdf5 tab!"))
		self.toolbar_sizer.Add(self.hdf5_cb, 0, wx.ALIGN_CENTER_VERTICAL | wx.ALIGN_LEFT, 5)
		self.hdf5_cb.Bind(wx.EVT_COMBOBOX, self.update_hdf5)
		self.hdf5_cb.Hide()
		
		#}}}
		
		sizer.Add(self.toolbar_panel)
		
		# StatusBar {{{
		self.statusBar = self.CreateStatusBar(2) # A Statusbar in the bottom of the window
		self.SetStatusWidths([-5,-2])
		self.statusBar.SetStatusText(" Welcome in the amrviewer gui !")
		#}}}
		
		# Frame Content {{{
		mainpanel = wx.Panel(self, WID.ANY, style=wx.RAISED_BORDER)
		sizer.Add(mainpanel, 1, wx.EXPAND)
		sizer2 = wx.BoxSizer(wx.HORIZONTAL)
		mainpanel.SetSizer(sizer2)
		self.lp = LeftPanel(mainpanel, self.model, self.controller)
		self.rp = Notebook(mainpanel, self.model, self.controller)
		sizer2.Add(self.lp, 0, wx.ALL|wx.EXPAND|wx.ALIGN_CENTER, 2)
		sizer2.Add(self.rp, 1, wx.ALL|wx.EXPAND|wx.ALIGN_CENTER, 2)
		#}}}
		
		# Widgets {{{
		self.widgets = {
				WID.EXPANDER_PARAMETERS: self.lp.cpp, \
				WID.EXPANDER_LOS: self.lp.cpa, \
				WID.EXPANDER_GLASS: self.lp.cpg, \
				WID.RF_TAB: self.rp.rf_tab, \
				}
		for tab_name, tab_id in WID.TAB_IDS.iteritems():
			self.widgets[tab_id] = self.rp.map_tabs[tab_name]
		#}}}
		
		# Controller
		self.controller.SetWidgetsDict(self.widgets)

		# Controller reset
		self.controller.OnReset(None)
		
		# Events binding
		self.bind_events()
		
		self.SetAutoLayout(1)
		self.Fit()
		self.SetMinSize(self.GetSize())
		self.Center()
		self.Show()
		
		# show tab by default
		for tab_name, tab_menu_id in WID.TAB_MENU_IDS.iteritems():
			if tab_name != "hdf5":
				tab = self.widgets[WID.TAB_IDS[tab_name]]
				tab.Show()
		
		# select current directory by default
		self.controller.SelectRamsesDir(abspath("./"))
	#}}}
		
	def reset(self):#{{{
		self.lp.reset()
		self.rp.reset()
	#}}}

	def bind_events(self):#{{{
		WID = wid()
		self.Bind(wx.EVT_MENU, self.OnOpen,    id=WID.MENU_OPEN)
		self.Bind(wx.EVT_TOOL, self.OnExit,    id=WID.MENU_QUIT)
		
		self.Bind(wx.EVT_MENU, self.OnLoadCam, id=WID.MENU_LOADCAM)
		self.Bind(wx.EVT_MENU, self.OnSaveCam, id=WID.MENU_SAVECAM)
		
		for tid in WID.TAB_MENU_IDS.values():
			self.Bind(wx.EVT_MENU, self.OnDisplayHideTab, id=tid)
		
		self.Bind(wx.EVT_MENU, self.OnAbout,   id=WID.MENU_ABOUT)
		
		self.Bind(wx.EVT_TOOL, self.OnOpen,    id=WID.TOOL_OPEN)
		self.Bind(wx.EVT_MENU, self.OnExit,    id=WID.TOOL_QUIT)
		self.Bind(wx.EVT_TOOL, self.controller.OnReset, id=WID.TOOL_RESET)
		self.Bind(wx.EVT_TOOL, self.controller.updateImages, id=WID.TOOL_UPDATE)
		self.Bind(wx.EVT_TOOL, self.OnSaveImg, id=WID.TOOL_SAVE_IMAGE)
	
		self.Bind(wx.EVT_COLLAPSIBLEPANE_CHANGED, self.UpdateLayout)
	#}}}

	def UpdateLayout(self, event):
		self.Layout()

	def OnAbout(self,event):
		open_about_box(self)
	
	def OnExit(self,event):#{{{
		dial = wx.MessageDialog(self, 'Are you sure you want to quit ?', 'Exit', \
				wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION)
		if dial.ShowModal() == wx.ID_YES:
			self.Close(True)
	#}}}
	
	def OnSaveImg(self,event):#{{{
		"""
		Open a CameraPNGFileDialog and let the user choose a PNG file
		in which a image is saved
		"""
		if self.controller.active_tab is None and self.rp.rf_tab.windows[wid().RF_TAB_LOS_WIN].image is not None:
			class SelectViewDialog(wx.Dialog):
				def __init__(self):
					wx.Dialog.__init__(self, None, -1, "Choose which region finder axis image to save",size=(410, 80))
					self.WID = wid()
					self.selected_view=self.WID.RF_TAB_LOS_WIN
					pan = wx.Panel(self, self.WID.ANY)
					los_view_btn = wx.Button(pan, -1, "line-of-sight", (50,30))
					los_view_btn.Bind(wx.EVT_BUTTON, self.On_los_view_btn)
					u_view_btn = wx.Button(pan, -1, "u view", (150,30))
					u_view_btn.Bind(wx.EVT_BUTTON, self.On_u_view_btn)
					v_view_btn = wx.Button(pan, -1, "v view", (250,30))
					v_view_btn.Bind(wx.EVT_BUTTON, self.On_v_view_btn)
					self.CentreOnParent(wx.BOTH)
					self.SetFocus()
				def On_los_view_btn(self, event):
					self.selected_view=self.WID.RF_TAB_LOS_WIN
					self.Destroy()
				def On_u_view_btn(self, event):
					self.selected_view=self.WID.RF_TAB_U_WIN
					self.Destroy()
				def On_v_view_btn(self, event):
					self.selected_view=self.WID.RF_TAB_V_WIN
					self.Destroy()
			selectViewDialog = SelectViewDialog()
			selectViewDialog.ShowModal()
			win = CameraPNGFileDialog(self, self.controller, self.rp.rf_tab.windows[selectViewDialog.selected_view].image)
			selectViewDialog.Destroy()
			win.run()
		elif self.controller.active_tab is not None and self.rp.map_tabs[self.controller.active_tab].window.image is not None: 
			win = CameraPNGFileDialog(self, self.controller, self.rp.map_tabs[self.controller.active_tab].window.image)
			win.run()
		else:
			print "There is no image to save!"
	#}}}
	
	def OnOpen(self,event):#{{{
		"""
		Open a RamsesSimOuputDialog
		"""
		WID = wid()
		win = RamsesSimOutputDialog(self, self.controller)
		win.run()
	#}}}
	
	def OnLoadCam(self,event):#{{{
		"""
		Open a CameraHDF5FileDialog and let the user choose a HDF5 file
		from which a Camera is loaded
		"""
		WID = wid()
		win = CameraHDF5FileDialog(self, self.controller, True)
		win.run()
	#}}}
	
	def OnSaveCam(self,event):#{{{
		"""
		Open a CameraHDF5FileDialog and let the user choose a HDF5 file
		in which a Camera is saved
		"""
		WID = wid()
		win = CameraHDF5FileDialog(self, self.controller, False)
		win.run()
	#}}}

	def OnDisplayHideTab(self, event):#{{{
		WID = wid()
		tid = event.GetId()
		for tab_name, tab_menu_id in WID.TAB_MENU_IDS.iteritems():
			if (tab_menu_id == tid):
				tab = self.widgets[WID.TAB_IDS[tab_name]]
				if tab.IsShown():
					tab.Hide()
				else:
					tab.Show()
					self.controller.ChangeActiveTab(tab_name)
					self.rp.ChangeSelection(WID.Tab_Number_for_selection[tab_name])
					if tab_name == "hdf5":
						win = HDF5FileDialog(self.controller)
						win.run()
						tab = self.controller.widgets[WID.TAB_IDS[tab_name]]
						tab.UpdateTabImage()
						tab.RefreshWholeTab(make_bitmap=True)
						self.list_hdf5_file = []
						self.hdf5_file = self.model.map_name_list["hdf5"][0]
						self.hdf5_file_dirname = os.path.dirname(self.hdf5_file)
						for file in os.listdir(self.hdf5_file_dirname):
							if os.path.splitext(file)[1] == ".h5" or os.path.splitext(file)[1] == ".hdf5":
								self.list_hdf5_file.append(file)
						self.hdf5_cb.Show(True)
						self.hdf5_cb.SetItems(self.list_hdf5_file)
						self.hdf5_cb.SetValue(os.path.basename(self.hdf5_file))
						self.UpdateLayout(None)
				break
	#}}}
	
	def update_hdf5(self, event):#{{{
		if self.controller.active_tab == "hdf5":
			self.model.LoadmapFromHDF5(self.hdf5_file_dirname + "/" + self.list_hdf5_file[event.GetSelection()])
			WID = wid()
			tab = self.widgets[WID.TAB_IDS["hdf5"]]
			tab.UpdateTabImage()
			tab.RefreshWholeTab(make_bitmap=True)
	#}}}
#}}}

def run():
	gui = GUI()
	gui.run()
