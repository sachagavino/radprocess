# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
"""
:mod:`pymses.core.sources` --- PyMSES generic data source module
================================================================

"""
from time import time

class Source(object):#{{{
	r"""
	Base class for all data source objects

	"""
	AMR_SOURCE = 10
	PARTICLE_SOURCE = 11
	def __init__(self):
		self.dom_decomp = None
		self._data_list = []
		self.read_lmax = None
		self.ndim = None

	def __del__(self):
		del self.dom_decomp
		del self._data_list

	def set_read_lmax(self, max_read_level):
		r"""Sets the maximum AMR grid level to read in the datasource

		Parameters
		----------
		max_read_level : ``int``
			max. AMR level to read

		"""
		assert (max_read_level > 0)
		self.read_lmax = int(max_read_level)

	def get_source_type(self):
		raise NotImplementedError()

	def iter_dsets(self):
		r"""
		Datasets iterator method. Yield datasets from the datasource

		"""
		for idata in self._data_list:
			yield self.get_domain_dset(idata)

	def __iter__(self):
		return self.iter_dsets()


	def get_domain_dset(self, idomain):
		raise NotImplementedError


	def flatten(self):
		"""
		Read each data file and concatenate resulting dsets.
		Try to use multiprocessing if possible.

		Returns
		-------

		fdset : flattened dataset

		"""
		startingTime = time()
		try:
			from multiprocessing import Process, Queue, cpu_count
			if cpu_count() == 1:
				raise(Exception) # don't use multiprocessing if there is only one cpu
			dsets = []
			from pymses.utils import misc
			NUMBER_OF_PROCESSES = min(len(self._data_list), cpu_count(), misc.NUMBER_OF_PROCESSES_LIMIT)

			# define long computing process method to do in parallel
			def read_dsets(cpu_task_queue, dsets_queue):
				"""Utility method for the Source.flatten() multiprocessing method. 
				It reads the given list of data file and concatenate resulting dsets
	
				Parameters
				----------
				cpu_task_queue : ``list`` of ``int``
					queue of data file number corresponding to data files that have to be read by a process
				dsets_queue : multiprocessing queue
					to send the result to parent process
			
				"""
				dsets = []
				for icpu in iter(cpu_task_queue.get, 'STOP'):
					dsets.append(self.get_domain_dset(icpu))
				len_dsets = len(dsets)
				if len_dsets == 0:
					dsets_queue.put("NoDset")
				elif len_dsets == 1:
					dsets_queue.put(dsets[0])
				else:
					dsets_queue.put(dsets)

			# Create queues
			cpu_task_queue = Queue()
			dsets_queue = Queue()
			# Submit tasks
			for task in self._data_list:
				cpu_task_queue.put(task)
			# Start worker processes
			for i in range(NUMBER_OF_PROCESSES):
				Process(target=read_dsets, args=(cpu_task_queue, dsets_queue)).start()
			# Tell child processes to stop when they have finished
			for i in range(NUMBER_OF_PROCESSES):
				cpu_task_queue.put('STOP')
			# Get results
			for i in range(NUMBER_OF_PROCESSES):
				dsets_queue_got = dsets_queue.get()
				if dsets_queue_got != "NoDset":
					dsets.extend(dsets_queue_got)
		except Exception:
			print 'WARNING: multiprocessing unavailable'
			dsets = list(self.iter_dsets())
		print "Reading files time = %.1f s"%(time()-startingTime)
		if dsets == []:
			return None
		else:
			return dsets[0].concatenate(dsets)
#}}}

class Filter(Source):#{{{
	r"""
	Data source filter generic class.

	"""
	def __init__(self, source):
		Source.__init__(self)
		self.source = source
		self.dom_decomp = source.dom_decomp
		self._data_list = source._data_list

	def __del__(self):
		del self.source
		del self.dom_decomp
		del self._data_list

	def set_read_lmax(self, max_read_level):
		r"""
		Source inherited behavior + apply the set_read_lmax() method to the `source` param.

		Parameters
		----------
		max_read_level : ``int``
			max. AMR level to read

		"""
		Source.set_read_lmax(self, max_read_level)
		self.source.set_read_lmax(max_read_level)

	def get_source_type(self):
		r"""
		Returns
		-------
		type : ``int``
			the result of the `get_source_type()` method of the `source` param.

		"""
		return self.source.get_source_type()

	def filtered_dset(self, dset):
		r"""
		Abstract `filtered_dset()` method

		"""
		raise NotImplementedError


	def get_domain_dset(self, idomain, fields_to_read=None):
		r"""
		Get the filtered result of `self.source.get_domain_dset(idomain)`

		Parameters
		----------
		idomain : ``int``
			number of the domain from which the data is required

		Returns
		-------
		dset : ``Dataset``
			the filtered dataset corresponding to the given `idomain`

		"""
		return self.filtered_dset(
				self.source.get_domain_dset(idomain, fields_to_read=fields_to_read) )
#}}}

class SubsetFilter(Filter):#{{{
	r"""
	SubsetFilter class. Selects a subset of datasets to read from the
	datasource

	Parameters
	----------
	data_sublist : ``list`` of ``int``
		list of the selected dataset index to read from the datasource

	"""
	def __init__(self, data_sublist, source):
		Filter.__init__(self, source)
		if data_sublist is not None:
			self._data_list = [i for i in data_sublist\
					if i in self._data_list]
	
	def filtered_dset(self, dset):
		return dset
#}}}

__all__ = ["Source", "Filter", "SubsetFilter"]
