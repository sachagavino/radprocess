# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
r"""
:mod:`pymses.sources.ramses.sources` --- RAMSES data sources module
-------------------------------------------------------------------

"""
from pymses.core import Source


class RamsesGenericSource(Source):
	r"""
	RAMSES generic data source

	"""
	def __init__(self, reader_list, dom_decomp=None, cpu_list=None, ndim=None):
		Source.__init__(self)
		self.readers = reader_list
		ncpu = len(reader_list)
		if cpu_list == None:
			cpu_list = range(1,ncpu+1)
		self._data_list = cpu_list
		self.dom_decomp = dom_decomp
		self.ndim = ndim

	def get_source_type(self):
		raise NotImplementedError()

	def get_domain_dset(self, icpu, fields_to_read=None):
		r"""
		Data source reading method

		Parameters
		----------
		icpu : ``int``
			CPU file number to read
		fields_to_read : ``list`` of ``strings``
			list of AMR data fields that needed to be read

		Returns
		-------
		dset : ``Dataset``
			the dataset containing the data from the given cpu number file

		"""
		return self.readers[self._data_list.index(icpu)].read(self.read_lmax,\
							fields_to_read=fields_to_read)

class RamsesAmrSource(RamsesGenericSource):
	r"""
	RAMSES AMR data source class

	"""
	def __init__(self, reader_list, dom_decomp=None, cpu_list=None, ndim=None):
		RamsesGenericSource.__init__(self, reader_list, dom_decomp, cpu_list, ndim)

	def get_source_type(self):
		r"""
		Returns
		-------
		Source.AMR_SOURCE
		
		"""
		return Source.AMR_SOURCE

class RamsesParticleSource(RamsesGenericSource):
	r"""
	RAMSES particle data source class

	"""
	def __init__(self, reader_list, dom_decomp=None, cpu_list=None, ndim=None):
		RamsesGenericSource.__init__(self, reader_list, dom_decomp, cpu_list, ndim)
	
	def get_source_type(self):
		r"""
		Returns
		-------
		Source.PARTICLE_SOURCE

		"""
		return Source.PARTICLE_SOURCE

__all__ = ["RamsesGenericSource", "RamsesAmrSource", "RamsesParticleSource"]
