# License:
#   Copyright (C) 2011 Thomas GUILLET, Damien CHAPON, Marc LABADENS. All Rights Reserved.
#
#   This file is part of PyMSES.
#
#   PyMSES is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PyMSES is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PyMSES.  If not, see <http://www.gnu.org/licenses/>.
from ramses_sim import RamsesSimController
from los_axes3d import LineOfSightController
from region_finder import RegionFinderController
from map_tabs import MapTabController
from ..view.dialogs import SelectParametersDialog
from ..view.widget_ids import WidgetIds as wid
import wx
from ..model import Model

class Controller(RamsesSimController, LineOfSightController, \
		RegionFinderController, MapTabController):
	def __init__(self, gui):
		self.gui = gui
		RamsesSimController.__init__(self)
		LineOfSightController.__init__(self)
		RegionFinderController.__init__(self)
		MapTabController.__init__(self)
		self.model = Model()

	def SetWidgetsDict(self, widgets):
		self.widgets = widgets

	def OnReset(self, event):
		self.model.reset()
		self.gui.reset()
	
	def OnPrevious(self, event):
		WID = wid()
		if self.active_tab != None:
			self.ChangeActiveTab(None)
			self.gui.rp.ChangeSelection(0)
		if len(self.model.map_name_list_history) > 1:
			self.model.region_finder_previous_cam()
			self.gui.reset()
			self.RegionFinderButtonClick(do_all_processing=False)
	
	def SaveLosCameraToFile(self, h5fname):
		return self.model.SaveLosCameraToFile(h5fname)

	def LoadLosCameraFromFile(self, h5fname):
		self.model.reset()
		self.model.LoadLosCameraFromFile(h5fname)
		self.gui.reset()
	
	def LoadmapFromHDF5(self, h5fname):
		self.model.LoadmapFromHDF5(h5fname)
	
	def BuildSource(self, event):
		WID = wid()
		self.model.update_cameras_dict(self.widgets[WID.RF_TAB].GetWindowSizesDict())
		cam = self.model.cam_dict["los"].copy()
		# extend loading by 2 AMR level:
		SelectParamDlg = SelectParametersDialog(cam.get_required_resolution() + 2)
		SelectParamDlg.ShowModal()
		if SelectParamDlg.load:
			lev = int(SelectParamDlg.levTextCtrl.GetValue())
			cam.map_max_size = 2**lev * max(cam.region_size) - 10
			# load every fields:
			fields_to_read = []
			if SelectParamDlg.rhoCheckBox.GetValue():
				fields_to_read.append("rho")
			if SelectParamDlg.PCheckBox.GetValue():
				fields_to_read.append("P")
			if SelectParamDlg.velCheckBox.GetValue():
				fields_to_read.append("vel")
			self.model.BuildSource(cam, fields_to_read, \
					ngrid_max=int(float(SelectParamDlg.\
						ngrid_maxTextCtrl.GetValue())))
		SelectParamDlg.Destroy()

	def UpdateImages(self, wx_event=None, do_all_processing=True, verbose=True):
		if self.active_tab == None:
			if self.model.image_computed.has_key("regionFinder") or do_all_processing:
				# this test avoid a bug when user try to change the color 
				# while image is not already computed
				self.RegionFinderButtonClick(do_all_processing=do_all_processing, verbose=verbose)
		elif self.model.image_computed.has_key(self.active_tab) or do_all_processing:
			# this test avoid a bug when user try to change the color 
			# while image is not already computed
			self.TabMapWindowUpdateClick(do_all_processing=do_all_processing, verbose=verbose)

	def SetRegionFinderHelpMessage(self):
		self.gui.statusBar.SetStatusText(" Left click on two axis views to define a zoom box center (right click = cancel)",0)
		self.gui.statusBar.SetStatusText(" Mouse wheel = zoom box size",1)



