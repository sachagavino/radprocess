import numpy
import tables
from pymses import RamsesOutput
from pymses.utils.regions import Cylinder, Sphere
from pymses.filters import RegionFilter, PointFunctionFilter
from pymses.analysis import sample_points, bin_cylindrical, bin_spherical
from pymses.utils import constants as C
from pymses.analysis.visualization import *


def test_cyl_profile():
	# Galactic cylinder parameters
	gal_center = [ 0.567811, 0.586055, 0.559156 ]        # in box units
	gal_radius = 0.00024132905460547268                  # in box units
	gal_thickn = 0.00010238202316595811                  # in box units
	gal_normal = [ -0.172935, 0.977948, -0.117099 ]      # Norm = 1
	
	# RamsesOutput
	ro = RamsesOutput("/data/Aquarius/output", 193)
	
	# Prepare to read the density field only
	source = ro.amr_source(["rho"])
	
	# Cylinder region
	cyl = Cylinder(gal_center, gal_normal, gal_radius, gal_thickn)
	
	# AMR density field point sampling
	points = cyl.random_points(1.0e6) # 1M sampling points
	point_dset = sample_points(source, points)
	rho_weight_func = lambda dset: dset["rho"]
	r_bins = numpy.linspace(0.0, gal_radius, 200)
	
	# Profile computation
	rho_profile = bin_cylindrical(point_dset, gal_center, gal_normal,
			rho_weight_func, r_bins, divide_by_counts=True)
		
	# Plot
	# Geometrical midpoint of the bins
	length = ro.info["unit_length"].express(C.kpc)
	bins_centers = (r_bins[1:]+r_bins[:-1])/2. * length
	dens = ro.info["unit_density"].express(C.H_cc)
	
	#h5f = tables.openFile("./long_tests/cyl_profile.h5", mode='w')
	#h5f.createArray("/", "cyl_profile", rho_profile)	
	#h5f.close()
	
	h5f = tables.openFile("./long_tests/cyl_profile.h5", mode='r')
	rho_profileB = h5f.getNode("/cyl_profile").read()	
	h5f.close()
	
	#print rho_profile
	assert sum(rho_profile - rho_profileB) < 10e-6
	
def test_sph_profile():
	# Halo parameters
	halo_center = [ 0.567811, 0.586055, 0.559156 ]        # in box units
	halo_radius = 0.00075                                  # in box units
	
	# RamsesOutput
	ro = RamsesOutput("/data/Aquarius/output", 193)
	
	# Prepare to read the mass/epoch fields only
	source = ro.particle_source(["mass", "epoch"])
	
	# Sphere region
	sph = Sphere(halo_center, halo_radius)
	
	# Filtering particles
	point_dset = RegionFilter(sph, source)
	dm_filter = lambda dset: dset["epoch"] == 0.0
	dm_parts = PointFunctionFilter(dm_filter, point_dset)
	
	# Profile computation
	m_weight_func = lambda dset: dset["mass"]
	r_bins = numpy.linspace(0.0, halo_radius, 200)
	
	# Mass profile
	# This triggers the actual reading of the particle data files from disk.
	mass_profile = bin_spherical(dm_parts, halo_center, m_weight_func, r_bins,
				     divide_by_counts=False)
	
	# Density profile
	sph_vol = 4.0/3.0 * numpy.pi * r_bins**3
	shell_vol = numpy.diff(sph_vol)
	rho_profile = mass_profile / shell_vol
	
	# Plot
	# Geometrical midpoint of the bins
	length = ro.info["unit_length"].express(C.kpc)
	bins_centers = (r_bins[1:]+r_bins[:-1])/2. * length
	dens = ro.info["unit_density"].express(C.Msun/C.kpc**3)
	
	#h5f = tables.openFile("./long_tests/sph_profile.h5", mode='w')
	#h5f.createArray("/", "sph_profile", rho_profile)	
	#h5f.close()
	
	h5f = tables.openFile("./long_tests/sph_profile.h5", mode='r')
	rho_profileB = h5f.getNode("/sph_profile").read()	
	h5f.close()
	
	#print rho_profile
	assert (rho_profile - rho_profileB).all() < 10e-6


def test_slice_density():
	# RamsesOutput
	ro = RamsesOutput("/data/Aquarius/output/", 193)
	
	# AMR data source
	amr = ro.amr_source(["rho"])
	
	# Defining a Camera object
	cam  = Camera(center=[0.5, 0.5, 0.5], line_of_sight_axis='z',
		      region_size=[1., 1.], up_vector='y', map_max_size=100,
		      log_sensitive=True)
	
	# Density field access operator
	rho_op = ScalarOperator(lambda dset: dset["rho"])
	
	# Slice map computation
	map = SliceMap(amr, cam, rho_op, z=0.4)
	# create a density slice map at z=0.4 depth position
	
	map = apply_log_scale(map)
	
	#h5f = tables.openFile("./long_tests/slice_density.h5", mode='w')
	#h5f.createArray("/", "map", map)	
	#h5f.close()
	
	h5f = tables.openFile("./long_tests/slice_density.h5", mode='r')
	mapB = h5f.getNode("/map").read()	
	h5f.close()
	
	#print map
	assert (map - mapB).all() < 10e-6
	
def test_rt_Tmin():
	# Ramses data
	ioutput = 193
	ro = RamsesOutput("/data/Aquarius/output/", ioutput)
	
	# Map operator : minimum temperature along line-of-sight
	class MyTempOperator(Operator):
		def __init__(self):
			def invT_func(dset):
				P = dset["P"]
				rho = dset["rho"]
				r = rho/P
	#			print r[(rho<=0.0)+(P<=0.0)]
	#			r[(rho<=0.0)*(P<=0.0)] = 0.0
				return r
			d = {"invTemp": invT_func}
			Operator.__init__(self, d, is_max_alos=True)
	
		def operation(self, int_dict):
				map = int_dict.values()[0]
				mask = (map == 0.0)
				mask2 = map != 0.0
				map[mask2] = 1.0 / map[mask2]
				map[mask] = 0.0
				return map
	scal_op = MyTempOperator()
	
	# Map region
	center = [ 0.567111, 0.586555, 0.559156 ]
	axes = {"los": "z"}
	
	# Map processing
	rt = raytracing.RayTracer(ro, ["rho", "P"])
	
	axname = "los"
	axis = "z"
	cam  = Camera(center=center, line_of_sight_axis=axis, up_vector="y", region_size=[3.0E-3, 3.0E-3], \
			distance=1.5E-3, far_cut_depth=1.5E-3, map_max_size=100)
	map = rt.process(scal_op, cam)
	
	#h5f = tables.openFile("./long_tests/rt_min.h5", mode='w')
	#h5f.createArray("/", "map", map)	
	#h5f.close()
	
	h5f = tables.openFile("./long_tests/rt_min.h5", mode='r')
	mapB = h5f.getNode("/map").read()	
	h5f.close()
	
	#print map
	assert (map - mapB).all() < 10e-6

def test_rt_rho():
	# Ramses data
	ioutput = 193
	ro = RamsesOutput("/data/Aquarius/output/", ioutput)
	
	# Map operator : mass-weighted density map
	up_func = lambda dset: (dset["rho"]**2)
	down_func = lambda dset: (dset["rho"])
	scal_op = FractionOperator(up_func, down_func)
	
	# Map region
	center = [ 0.567811, 0.586055, 0.559156 ]
	# Map processing
	rt = raytracing.RayTracer(ro, ["rho"])
	axname = "los"
	axis = [ -0.172935, 0.977948, -0.117099 ]
	cam  = Camera(center=center, line_of_sight_axis=axis, up_vector="z", region_size=[3.0E-2, 3.0E-2], \
			distance=2.0E-2, far_cut_depth=2.0E-2, map_max_size=100)
	map = rt.process(scal_op, cam)
	
	#h5f = tables.openFile("./long_tests/rt_rho.h5", mode='w')
	#h5f.createArray("/", "map", map)	
	#h5f.close()
	
	h5f = tables.openFile("./long_tests/rt_rho.h5", mode='r')
	mapB = h5f.getNode("/map").read()	
	h5f.close()
	
	#print map
	assert (map - mapB).all() < 10e-6

def test_rt_lmax():
	# Ramses data
	ioutput = 193
	ro = RamsesOutput("/data/Aquarius/output/", ioutput)
	
	# Map operator : max. AMR level of refinement along the line-of-sight
	scal_op = MaxLevelOperator()
	
	# Map region
	center = [ 0.567811, 0.586055, 0.559156 ]
	# Map processing
	rt = raytracing.RayTracer(ro, ["rho"])
	axname = "los"
	axis = [ -0.172935, 0.977948, -0.117099 ]
	cam  = Camera(center=center, line_of_sight_axis=axis, up_vector="z", region_size=[3.0E-2, 3.0E-2], \
			distance=2.0E-2, far_cut_depth=2.0E-2, map_max_size=100)
	map = rt.process(scal_op, cam)
	
	#h5f = tables.openFile("./long_tests/rt_lmax.h5", mode='w')
	#h5f.createArray("/", "map", map)	
	#h5f.close()
	
	h5f = tables.openFile("./long_tests/rt_lmax.h5", mode='r')
	mapB = h5f.getNode("/map").read()	
	h5f.close()
	
	#print map
	assert (map - mapB).all() < 10e-6

def test_fft_part():
	# Ramses data
	ioutput = 193
	ro = RamsesOutput("/data/Aquarius/output/", ioutput)
	parts = ro.particle_source(["mass", "level"])
	
	# Map operator : mass
	scal_func = ScalarOperator(lambda dset: dset["mass"])
	
	# Map region
	center = [ 0.567811, 0.586055, 0.559156 ]
	
	# Map processing
	mp = fft_projection.MapFFTProcessor(parts, ro.info)
	
	axname = "los"
	axis = [ -0.172935, 0.977948, -0.117099 ]
	
	cam  = Camera(center=center, line_of_sight_axis=axis, up_vector="z", region_size=[5.0E-1, 4.5E-1], \
			distance=2.0E-1, far_cut_depth=2.0E-1, map_max_size=100)
	map = mp.process(scal_func, cam, surf_qty=True)
	
	#h5f = tables.openFile("./long_tests/fft_part.h5", mode='w')
	#h5f.createArray("/", "map", map)	
	#h5f.close()
	
	h5f = tables.openFile("./long_tests/fft_part.h5", mode='r')
	mapB = h5f.getNode("/map").read()	
	h5f.close()
	
	#print map
	assert (map - mapB).all() < 10e-6
	
def test_fft_amr():
	# Ramses data
	ioutput = 193
	ro = RamsesOutput("/data/Aquarius/output/", ioutput)
	amr = ro.amr_source(["rho", "P"])

	# Map operator : mass-weighted density map
	up_func = lambda dset: (dset["rho"]**2 * dset.get_sizes()**3)
	down_func = lambda dset: (dset["rho"] * dset.get_sizes()**3)
	scal_func = FractionOperator(up_func, down_func)
	
	# Map region
	center = [ 0.567811, 0.586055, 0.559156 ]
	
	# Map processing
	mp = fft_projection.MapFFTProcessor(amr, ro.info)
	
	axname = "los"
	axis = [ -0.172935, 0.977948, -0.117099 ]
	
	cam  = Camera(center=center, line_of_sight_axis=axis, up_vector="z", region_size=[5.0E-1, 4.5E-1], \
			distance=2.0E-1, far_cut_depth=2.0E-1, map_max_size=100)
	map = mp.process(scal_func, cam, surf_qty=True)
	
	#h5f = tables.openFile("./long_tests/fft_amr.h5", mode='w')
	#h5f.createArray("/", "map", map)	
	#h5f.close()
	
	h5f = tables.openFile("./long_tests/fft_amr.h5", mode='r')
	mapB = h5f.getNode("/map").read()	
	h5f.close()
	
	#print map
	assert (map - mapB).all() < 10e-6
	